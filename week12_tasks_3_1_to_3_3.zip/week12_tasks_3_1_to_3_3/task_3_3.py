import pygame
import sys

pygame.init()

WIDTH, HEIGHT = 720, 780
ROWS, COLS = 6, 6
CELL_SIZE = WIDTH // COLS

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Task 3.3 - Dynamic Programming Grid Path Visualizer")

FONT = pygame.font.SysFont(None, 32)
SMALL_FONT = pygame.font.SysFont(None, 22)
clock = pygame.time.Clock()

obstacles = {(1, 2), (2, 2), (3, 4), (4, 1)}
valid_path = []
message = "Click cells to add/remove obstacles. Press SPACE to calculate paths. Press C for coin change. Press R to reset."


def draw_grid(dp=None, highlight=None, path=None):
    if dp is None:
        dp = [[None] * COLS for _ in range(ROWS)]

    if path is None:
        path = []

    screen.fill((255, 255, 255))

    title = FONT.render("Dynamic Programming Grid Path Counting", True, (0, 0, 0))
    screen.blit(title, (20, 725))

    info = SMALL_FONT.render(message, True, (0, 0, 0))
    screen.blit(info, (20, 755))

    for r in range(ROWS):
        for c in range(COLS):
            rect = pygame.Rect(c * CELL_SIZE, r * CELL_SIZE, CELL_SIZE, CELL_SIZE)

            color = (210, 210, 210)

            if (r, c) in obstacles:
                color = (40, 40, 40)

            if highlight == (r, c):
                color = (255, 180, 180)

            if (r, c) in path:
                color = (120, 255, 120)

            if (r, c) == (0, 0):
                color = (170, 210, 255)

            if (r, c) == (ROWS - 1, COLS - 1):
                color = (255, 220, 150)

            pygame.draw.rect(screen, color, rect)
            pygame.draw.rect(screen, (0, 0, 0), rect, 2)

            if (r, c) not in obstacles and dp[r][c] is not None:
                text = FONT.render(str(dp[r][c]), True, (0, 0, 0))
                screen.blit(text, text.get_rect(center=rect.center))

    pygame.display.flip()


def check_quit_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()


def compute_paths_with_obstacles():
    global message, valid_path

    dp = [[0] * COLS for _ in range(ROWS)]
    parent = [[None] * COLS for _ in range(ROWS)]
    valid_path = []

    for r in range(ROWS):
        for c in range(COLS):
            check_quit_events()

            if (r, c) in obstacles:
                dp[r][c] = 0
                draw_grid(dp, highlight=(r, c))
                pygame.time.wait(300)
                continue

            if r == 0 and c == 0:
                dp[r][c] = 1
            else:
                up = dp[r - 1][c] if r > 0 else 0
                left = dp[r][c - 1] if c > 0 else 0
                dp[r][c] = up + left

                # Store one valid parent so a path can be reconstructed
                if r > 0 and dp[r - 1][c] > 0:
                    parent[r][c] = (r - 1, c)
                elif c > 0 and dp[r][c - 1] > 0:
                    parent[r][c] = (r, c - 1)

            draw_grid(dp, highlight=(r, c))
            pygame.time.wait(350)

    total_paths = dp[ROWS - 1][COLS - 1]
    message = f"Total unique paths with obstacles: {total_paths}"

    if total_paths > 0:
        path = []
        current = (ROWS - 1, COLS - 1)

        while current is not None:
            path.append(current)
            r, c = current
            current = parent[r][c]

        valid_path = list(reversed(path))

        for i in range(len(valid_path)):
            check_quit_events()
            draw_grid(dp, path=valid_path[:i + 1])
            pygame.time.wait(250)
    else:
        message = "No valid path exists."

    draw_grid(dp, path=valid_path)
    return dp


def draw_coin_change(dp, coins, amount, highlight_index=None):
    screen.fill((245, 245, 245))

    title = FONT.render("Coin Change DP Visualization", True, (0, 0, 0))
    screen.blit(title, (20, 20))

    subtitle = SMALL_FONT.render(f"Coins: {coins} | Target amount: {amount}", True, (0, 0, 0))
    screen.blit(subtitle, (20, 55))

    rule = SMALL_FONT.render("dp[x] = minimum coins needed to make amount x", True, (0, 0, 0))
    screen.blit(rule, (20, 80))

    box_width = 60
    start_x = 40
    start_y = 140

    for i, value in enumerate(dp):
        x = start_x + (i % 10) * box_width
        y = start_y + (i // 10) * 80

        color = (210, 210, 210)
        if i == highlight_index:
            color = (255, 180, 180)

        pygame.draw.rect(screen, color, (x, y, box_width - 5, 45))
        pygame.draw.rect(screen, (0, 0, 0), (x, y, box_width - 5, 45), 2)

        amount_label = SMALL_FONT.render(str(i), True, (0, 0, 0))
        screen.blit(amount_label, (x + 20, y - 22))

        display_value = "∞" if value == float("inf") else str(value)
        value_label = SMALL_FONT.render(display_value, True, (0, 0, 0))
        screen.blit(value_label, value_label.get_rect(center=(x + 27, y + 22)))

    exit_text = SMALL_FONT.render("Press any key to return to grid.", True, (0, 0, 0))
    screen.blit(exit_text, (20, HEIGHT - 35))

    pygame.display.flip()


def coin_change_visualization():
    global message

    coins = [1, 3, 4]
    amount = 12
    dp = [float("inf")] * (amount + 1)
    dp[0] = 0

    for current_amount in range(1, amount + 1):
        for coin in coins:
            check_quit_events()

            if coin <= current_amount:
                dp[current_amount] = min(dp[current_amount], dp[current_amount - coin] + 1)

            draw_coin_change(dp, coins, amount, highlight_index=current_amount)
            pygame.time.wait(350)

    result = dp[amount]
    message = f"Coin change completed. Minimum coins for {amount}: {result}"
    draw_coin_change(dp, coins, amount, highlight_index=amount)

    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False

        clock.tick(30)


def get_clicked_cell(pos):
    mouse_x, mouse_y = pos

    if mouse_y >= ROWS * CELL_SIZE:
        return None

    row = mouse_y // CELL_SIZE
    col = mouse_x // CELL_SIZE

    if 0 <= row < ROWS and 0 <= col < COLS:
        return row, col

    return None


def reset_obstacles():
    global obstacles, valid_path, message
    obstacles = {(1, 2), (2, 2), (3, 4), (4, 1)}
    valid_path = []
    message = "Obstacles reset. Press SPACE to calculate paths."


def main():
    global message, valid_path

    running = True

    while running:
        draw_grid(path=valid_path)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

                elif event.key == pygame.K_SPACE:
                    compute_paths_with_obstacles()

                elif event.key == pygame.K_c:
                    coin_change_visualization()

                elif event.key == pygame.K_r:
                    reset_obstacles()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                cell = get_clicked_cell(event.pos)

                if cell:
                    if cell in [(0, 0), (ROWS - 1, COLS - 1)]:
                        message = "Start and finish cells cannot be obstacles."
                    elif cell in obstacles:
                        obstacles.remove(cell)
                        valid_path = []
                        message = f"Removed obstacle at {cell}."
                    else:
                        obstacles.add(cell)
                        valid_path = []
                        message = f"Added obstacle at {cell}."

        clock.tick(30)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
