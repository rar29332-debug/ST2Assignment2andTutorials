Week 12 Tasks 3.1 to 3.3 - PyGame DSA Playground

Install pygame:
pip install pygame

Run each task:
python task_3_1.py
python task_3_2.py
python task_3_3.py

Task 3.1:
- Click a graph node to choose the start point.
- Press B or click BFS to run BFS.
- Press D or click DFS to run DFS.
- Traversal order is displayed on screen.

Task 3.2:
- Uses a min-heap priority queue.
- Each event has a time and description.
- Type event time, press ENTER, type event description, press ENTER.
- Click Process Earliest to pop and display the earliest event.
- Upcoming events are shown on the right.

Task 3.3:
- Click cells to add/remove obstacles.
- Press SPACE to calculate paths using DP.
- One valid path is reconstructed and highlighted.
- Press C to run a different DP visualization: coin change.
- Press R to reset obstacles.
