import pygame
import sys
import collections

pygame.init()

WIDTH, HEIGHT = 850, 520
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Task 3.1 - Graph BFS and DFS Visualizer")

FONT = pygame.font.SysFont(None, 28)
SMALL_FONT = pygame.font.SysFont(None, 22)
clock = pygame.time.Clock()

NODE_RADIUS = 28

nodes_pos = {
    "A": (120, 130),
    "B": (280, 80),
    "C": (280, 220),
    "D": (470, 120),
    "E": (640, 180),
    "F": (470, 330),
}

graph = {
    "A": ["B", "C"],
    "B": ["A", "D", "E"],
    "C": ["A", "F"],
    "D": ["B"],
    "E": ["B", "F"],
    "F": ["C", "E"],
}

message = "Click a node to choose a start point. Press B for BFS or D for DFS."
selected_start = None
traversal_order = []


def draw_button(rect, text):
    pygame.draw.rect(screen, (170, 170, 230), rect)
    pygame.draw.rect(screen, (0, 0, 0), rect, 2)
    label = SMALL_FONT.render(text, True, (0, 0, 0))
    screen.blit(label, label.get_rect(center=rect.center))


def draw_graph(visited=None, frontier=None, current=None, order=None):
    if visited is None:
        visited = set()
    if frontier is None:
        frontier = set()
    if order is None:
        order = []

    screen.fill((240, 240, 240))

    title = FONT.render("Graph Traversal Visualizer", True, (0, 0, 0))
    screen.blit(title, (20, 15))

    info = SMALL_FONT.render(message, True, (0, 0, 0))
    screen.blit(info, (20, 45))

    start_text = SMALL_FONT.render(f"Selected start node: {selected_start if selected_start else 'None'}", True, (0, 0, 0))
    screen.blit(start_text, (20, 70))

    order_text = "Traversal order: " + (" -> ".join(order) if order else "None")
    rendered_order = SMALL_FONT.render(order_text, True, (0, 0, 0))
    screen.blit(rendered_order, (20, HEIGHT - 40))

    # Draw edges once for undirected graph
    drawn_edges = set()
    for node, neighbours in graph.items():
        x1, y1 = nodes_pos[node]
        for neighbour in neighbours:
            edge_key = tuple(sorted((node, neighbour)))
            if edge_key not in drawn_edges:
                x2, y2 = nodes_pos[neighbour]
                pygame.draw.line(screen, (0, 0, 0), (x1, y1), (x2, y2), 3)
                drawn_edges.add(edge_key)

    # Draw nodes
    for node, (x, y) in nodes_pos.items():
        color = (210, 210, 210)

        if node == selected_start:
            color = (180, 180, 255)

        if node in visited:
            color = (120, 220, 120)

        if node in frontier:
            color = (255, 210, 100)

        if node == current:
            color = (255, 110, 110)

        pygame.draw.circle(screen, color, (x, y), NODE_RADIUS)
        pygame.draw.circle(screen, (0, 0, 0), (x, y), NODE_RADIUS, 2)

        label = FONT.render(node, True, (0, 0, 0))
        screen.blit(label, label.get_rect(center=(x, y)))

    bfs_button = pygame.Rect(610, 25, 90, 38)
    dfs_button = pygame.Rect(720, 25, 90, 38)
    draw_button(bfs_button, "BFS")
    draw_button(dfs_button, "DFS")

    pygame.display.flip()
    return bfs_button, dfs_button


def check_quit_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()


def get_clicked_node(pos):
    mouse_x, mouse_y = pos

    for node, (x, y) in nodes_pos.items():
        distance = ((mouse_x - x) ** 2 + (mouse_y - y) ** 2) ** 0.5
        if distance <= NODE_RADIUS:
            return node

    return None


def bfs(start):
    global traversal_order, message

    visited = set()
    queue = collections.deque([start])
    traversal_order = []

    while queue:
        check_quit_events()

        current = queue.popleft()

        if current in visited:
            continue

        visited.add(current)
        traversal_order.append(current)

        message = f"BFS visiting node {current}."
        draw_graph(visited=visited, frontier=set(queue), current=current, order=traversal_order)
        pygame.time.wait(700)

        for neighbour in graph[current]:
            if neighbour not in visited and neighbour not in queue:
                queue.append(neighbour)

        draw_graph(visited=visited, frontier=set(queue), current=current, order=traversal_order)
        pygame.time.wait(350)

    message = "BFS completed."


def dfs(start):
    global traversal_order, message

    visited = set()
    stack = [start]
    traversal_order = []

    while stack:
        check_quit_events()

        current = stack.pop()

        if current in visited:
            continue

        visited.add(current)
        traversal_order.append(current)

        message = f"DFS visiting node {current}."
        draw_graph(visited=visited, frontier=set(stack), current=current, order=traversal_order)
        pygame.time.wait(700)

        # Reverse neighbours so the visual order stays natural from left to right
        for neighbour in reversed(graph[current]):
            if neighbour not in visited and neighbour not in stack:
                stack.append(neighbour)

        draw_graph(visited=visited, frontier=set(stack), current=current, order=traversal_order)
        pygame.time.wait(350)

    message = "DFS completed."


def main():
    global selected_start, message

    running = True

    while running:
        bfs_button, dfs_button = draw_graph(order=traversal_order)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

                elif event.key == pygame.K_b:
                    if selected_start:
                        bfs(selected_start)
                    else:
                        message = "Please click a start node first."

                elif event.key == pygame.K_d:
                    if selected_start:
                        dfs(selected_start)
                    else:
                        message = "Please click a start node first."

            elif event.type == pygame.MOUSEBUTTONDOWN:
                clicked_node = get_clicked_node(event.pos)

                if clicked_node:
                    selected_start = clicked_node
                    message = f"Selected start node {selected_start}. Press B for BFS or D for DFS."

                elif bfs_button.collidepoint(event.pos):
                    if selected_start:
                        bfs(selected_start)
                    else:
                        message = "Please click a start node first."

                elif dfs_button.collidepoint(event.pos):
                    if selected_start:
                        dfs(selected_start)
                    else:
                        message = "Please click a start node first."

        clock.tick(30)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
