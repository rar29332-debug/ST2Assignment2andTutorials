import pygame
import sys
import math

pygame.init()

WIDTH, HEIGHT = 950, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Task 3.2 - Priority Queue Event Simulator")

FONT = pygame.font.SysFont(None, 26)
SMALL_FONT = pygame.font.SysFont(None, 21)
clock = pygame.time.Clock()

input_text = ""
mode = "time"
message = "Add event: type time, press ENTER, then type description and press ENTER."
current_time = None
last_processed = "None"

heap = []  # Each event is stored as a tuple: (time, description)

add_button = pygame.Rect(30, 535, 150, 40)
process_button = pygame.Rect(210, 535, 180, 40)
reset_button = pygame.Rect(420, 535, 150, 40)


def draw_button(rect, text):
    pygame.draw.rect(screen, (170, 170, 230), rect)
    pygame.draw.rect(screen, (0, 0, 0), rect, 2)
    label = SMALL_FONT.render(text, True, (0, 0, 0))
    screen.blit(label, label.get_rect(center=rect.center))


def event_label(event):
    return f"{event[0]}: {event[1]}"


def draw_heap(highlight_indices=None):
    if highlight_indices is None:
        highlight_indices = []

    screen.fill((255, 255, 255))

    title = FONT.render("Priority Queue Event Simulator using Min-Heap", True, (0, 0, 0))
    screen.blit(title, (20, 15))

    info = SMALL_FONT.render(message, True, (0, 0, 0))
    screen.blit(info, (20, 45))

    input_display = SMALL_FONT.render(f"Mode: {mode.upper()} | Input: {input_text}", True, (0, 0, 0))
    screen.blit(input_display, (20, 70))

    processed = SMALL_FONT.render(f"Last processed event: {last_processed}", True, (0, 0, 0))
    screen.blit(processed, (20, 95))

    upcoming_title = SMALL_FONT.render("Upcoming events:", True, (0, 0, 0))
    screen.blit(upcoming_title, (720, 40))

    for i, event in enumerate(sorted(heap)[:8]):
        line = SMALL_FONT.render(event_label(event), True, (0, 0, 0))
        screen.blit(line, (720, 65 + i * 24))

    if not heap:
        empty_text = FONT.render("Heap is empty", True, (0, 0, 0))
        screen.blit(empty_text, (WIDTH // 2 - 70, HEIGHT // 2))
    else:
        node_positions = []

        for i in range(len(heap)):
            level = int(math.floor(math.log2(i + 1)))
            index_in_level = i - (2 ** level - 1)
            gap = 620 // (2 ** level + 1)
            x = gap * (index_in_level + 1) + 30
            y = 160 + level * 75
            node_positions.append((x, y))

        for i in range(len(heap)):
            left = 2 * i + 1
            right = 2 * i + 2

            if left < len(heap):
                pygame.draw.line(screen, (0, 0, 0), node_positions[i], node_positions[left], 2)

            if right < len(heap):
                pygame.draw.line(screen, (0, 0, 0), node_positions[i], node_positions[right], 2)

        for i, event in enumerate(heap):
            color = (100, 200, 250)

            if i in highlight_indices:
                color = (255, 120, 120)

            pygame.draw.circle(screen, color, node_positions[i], 26)
            pygame.draw.circle(screen, (0, 0, 0), node_positions[i], 26, 2)

            label = FONT.render(str(event[0]), True, (0, 0, 0))
            screen.blit(label, label.get_rect(center=node_positions[i]))

            desc = SMALL_FONT.render(event[1][:10], True, (0, 0, 0))
            screen.blit(desc, (node_positions[i][0] - 35, node_positions[i][1] + 30))

    draw_button(add_button, "Add Event")
    draw_button(process_button, "Process Earliest")
    draw_button(reset_button, "Reset")

    pygame.display.flip()


def check_quit_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()


def heapify_up(index):
    while index > 0:
        parent = (index - 1) // 2

        if heap[parent][0] > heap[index][0]:
            heap[parent], heap[index] = heap[index], heap[parent]
            draw_heap([parent, index])
            pygame.time.wait(450)
            index = parent
        else:
            break


def heapify_down(index):
    n = len(heap)

    while True:
        left = 2 * index + 1
        right = 2 * index + 2
        smallest = index

        if left < n and heap[left][0] < heap[smallest][0]:
            smallest = left

        if right < n and heap[right][0] < heap[smallest][0]:
            smallest = right

        if smallest != index:
            heap[index], heap[smallest] = heap[smallest], heap[index]
            draw_heap([index, smallest])
            pygame.time.wait(450)
            index = smallest
        else:
            break


def insert_event(event_time, description):
    heap.append((event_time, description))
    draw_heap([len(heap) - 1])
    pygame.time.wait(350)
    heapify_up(len(heap) - 1)


def extract_min():
    if not heap:
        return None

    earliest = heap[0]

    if len(heap) == 1:
        heap.pop()
        draw_heap()
        return earliest

    heap[0] = heap[-1]
    heap.pop()
    draw_heap([0])
    pygame.time.wait(350)
    heapify_down(0)

    return earliest


def seed_events():
    sample_events = [
        (9, "Open lab"),
        (13, "Submit quiz"),
        (3, "Start class"),
        (18, "Team meeting"),
        (6, "Check email"),
    ]

    for event_time, description in sample_events:
        insert_event(event_time, description)


def process_event():
    global last_processed, message

    event = extract_min()

    if event:
        last_processed = event_label(event)
        message = f"Processed earliest event: {last_processed}"
    else:
        message = "No events to process."


def main():
    global input_text, mode, message, current_time, last_processed

    running = True
    seed_events()
    message = "Sample events added. Type a time or use Process Earliest."

    while running:
        draw_heap()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

                elif event.key == pygame.K_BACKSPACE:
                    input_text = input_text[:-1]

                elif event.key == pygame.K_RETURN:
                    if mode == "time":
                        try:
                            current_time = int(input_text)
                            input_text = ""
                            mode = "description"
                            message = "Now type the event description and press ENTER."
                        except ValueError:
                            input_text = ""
                            message = "Invalid time. Please type an integer."

                    elif mode == "description":
                        if input_text.strip():
                            insert_event(current_time, input_text.strip())
                            message = f"Added event at time {current_time}."
                            input_text = ""
                            current_time = None
                            mode = "time"
                        else:
                            message = "Description cannot be empty."

                else:
                    if mode == "time":
                        if event.unicode.isdigit() or event.unicode == "-":
                            input_text += event.unicode
                    else:
                        if event.unicode:
                            input_text += event.unicode

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if add_button.collidepoint(event.pos):
                    mode = "time"
                    input_text = ""
                    message = "Type the event time and press ENTER."

                elif process_button.collidepoint(event.pos):
                    process_event()

                elif reset_button.collidepoint(event.pos):
                    heap.clear()
                    last_processed = "None"
                    input_text = ""
                    mode = "time"
                    seed_events()
                    message = "Reset with sample events."

        clock.tick(30)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
