class Queue:
    def __init__(self):
        self._data = []

    def enqueue(self, val):
        self._data.append(val)

    def dequeue(self):
        if not self.is_empty():
            return self._data.pop(0)
        raise IndexError("dequeue from empty queue")

    def front(self):
        if not self.is_empty():
            return self._data[0]
        raise IndexError("front from empty queue")

    def is_empty(self):
        return len(self._data) == 0

    def size(self):
        return len(self._data)

    def to_list(self):
        return list(self._data)

    def __repr__(self):
        return f"Queue({self._data})"
