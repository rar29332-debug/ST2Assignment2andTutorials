import pygame
import sys
from modules.stack import Stack
from modules.queue_ds import Queue

WIDTH, HEIGHT = 800, 600
clock = pygame.time.Clock()

BLOCK_WIDTH, BLOCK_HEIGHT = 200, 40
STACK_X = (WIDTH - BLOCK_WIDTH) // 2
STACK_BASE_Y = HEIGHT - BLOCK_HEIGHT - 50

QUEUE_BLOCK_WIDTH, QUEUE_BLOCK_HEIGHT = 70, 50
QUEUE_START_X = 120
QUEUE_Y = 260


def draw_button(screen, font, rect, text):
    pygame.draw.rect(screen, (150, 150, 220), rect)
    pygame.draw.rect(screen, (0, 0, 0), rect, 2)
    label = font.render(text, True, (0, 0, 0))
    screen.blit(label, label.get_rect(center=rect.center))


def stack_visualization(screen, font):
    stack = Stack()
    counter = 1
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    stack.push(counter)
                    counter += 1

                elif event.key == pygame.K_BACKSPACE and not stack.is_empty():
                    stack.pop()

                elif event.key == pygame.K_ESCAPE:
                    running = False

        screen.fill((50, 50, 50))

        for i, val in enumerate(stack.to_list()):
            rect = pygame.Rect(
                STACK_X,
                STACK_BASE_Y - i * (BLOCK_HEIGHT + 5),
                BLOCK_WIDTH,
                BLOCK_HEIGHT
            )
            pygame.draw.rect(screen, (100, 150, 250), rect)
            pygame.draw.rect(screen, (0, 0, 0), rect, 2)
            text = font.render(str(val), True, (0, 0, 0))
            screen.blit(text, text.get_rect(center=rect.center))

        info_text = font.render("SPACE: Push | BACKSPACE: Pop | ESC: Return", True, (230, 230, 230))
        screen.blit(info_text, (10, 10))

        pygame.display.flip()
        clock.tick(30)


def draw_queue(screen, font, queue, moving_block=None):
    screen.fill((45, 45, 45))

    title = font.render("Queue Visualization - FIFO", True, (255, 255, 255))
    screen.blit(title, (20, 20))

    for i, val in enumerate(queue.to_list()):
        x = QUEUE_START_X + i * (QUEUE_BLOCK_WIDTH + 10)
        rect = pygame.Rect(x, QUEUE_Y, QUEUE_BLOCK_WIDTH, QUEUE_BLOCK_HEIGHT)
        pygame.draw.rect(screen, (100, 180, 255), rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)
        label = font.render(str(val), True, (0, 0, 0))
        screen.blit(label, label.get_rect(center=rect.center))

    if moving_block:
        x, y, val = moving_block
        rect = pygame.Rect(x, y, QUEUE_BLOCK_WIDTH, QUEUE_BLOCK_HEIGHT)
        pygame.draw.rect(screen, (255, 180, 100), rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)
        label = font.render(str(val), True, (0, 0, 0))
        screen.blit(label, label.get_rect(center=rect.center))

    enqueue_button = pygame.Rect(160, 500, 160, 45)
    dequeue_button = pygame.Rect(480, 500, 160, 45)
    draw_button(screen, font, enqueue_button, "Enqueue")
    draw_button(screen, font, dequeue_button, "Dequeue")

    instruction = font.render("Click buttons | ESC: Return", True, (230, 230, 230))
    screen.blit(instruction, (20, 70))

    pygame.display.flip()
    return enqueue_button, dequeue_button


def check_quit_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()


def animate_enqueue(screen, font, queue, value):
    target_x = QUEUE_START_X + queue.size() * (QUEUE_BLOCK_WIDTH + 10)
    x = WIDTH
    y = QUEUE_Y

    while x > target_x:
        check_quit_events()
        draw_queue(screen, font, queue, (x, y, value))
        x -= 18
        clock.tick(60)


def animate_dequeue(screen, font, queue, value):
    x = QUEUE_START_X
    y = QUEUE_Y

    while x > -QUEUE_BLOCK_WIDTH:
        check_quit_events()
        draw_queue(screen, font, queue, (x, y, value))
        x -= 18
        clock.tick(60)


def queue_visualization(screen, font):
    queue = Queue()
    counter = 1
    running = True

    while running:
        enqueue_button, dequeue_button = draw_queue(screen, font, queue)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if enqueue_button.collidepoint(event.pos):
                    animate_enqueue(screen, font, queue, counter)
                    queue.enqueue(counter)
                    counter += 1

                elif dequeue_button.collidepoint(event.pos) and not queue.is_empty():
                    value = queue.dequeue()
                    animate_dequeue(screen, font, queue, value)

        clock.tick(30)


def run(screen):
    font = pygame.font.SysFont(None, 30)

    menu_items = [
        "Stack Visualization",
        "Queue Visualization",
        "Back"
    ]

    selected = 0
    running = True

    while running:
        screen.fill((220, 220, 220))

        title = font.render("Data Structures Visualiser", True, (0, 0, 0))
        screen.blit(title, (100, 50))

        for i, item in enumerate(menu_items):
            color = (255, 0, 0) if i == selected else (0, 0, 0)
            text = font.render(item, True, color)
            screen.blit(text, (100, 130 + i * 45))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    selected = (selected + 1) % len(menu_items)

                elif event.key == pygame.K_UP:
                    selected = (selected - 1) % len(menu_items)

                elif event.key == pygame.K_RETURN:
                    choice = menu_items[selected]

                    if choice == "Stack Visualization":
                        stack_visualization(screen, font)

                    elif choice == "Queue Visualization":
                        queue_visualization(screen, font)

                    elif choice == "Back":
                        running = False

        clock.tick(30)
