Week 10 Tasks 1.1 to 1.4 - PyGame DSA Playground

How to run:

1. Install pygame:
   pip install pygame

2. Task 1.1:
   python task_1_1.py

3. Task 1.2:
   python task_1_2.py

4. Task 1.3 integrated DSA Explorer:
   python data_structures_tester.py

5. Task 1.4 automated tests:
   python -m unittest tests.test_stack
   python -m unittest tests.test_queue

Project structure:
- task_1_1.py
- task_1_2.py
- data_structures_tester.py
- modules/
  - stack.py
  - queue_ds.py
  - data_structures_visualiser.py
- tests/
  - test_stack.py
  - test_queue.py
