import pygame
import sys

pygame.init()

WIDTH, HEIGHT = 800, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Task 1.2 - Queue Visualization")

FONT = pygame.font.SysFont(None, 30)
SMALL_FONT = pygame.font.SysFont(None, 24)
clock = pygame.time.Clock()

queue = []
counter = 1

BLOCK_WIDTH, BLOCK_HEIGHT = 70, 50
QUEUE_Y = 190
START_X = 120

enqueue_button = pygame.Rect(160, 320, 160, 45)
dequeue_button = pygame.Rect(480, 320, 160, 45)


def draw_button(rect, text):
    pygame.draw.rect(screen, (150, 150, 220), rect)
    pygame.draw.rect(screen, (0, 0, 0), rect, 2)
    label = FONT.render(text, True, (0, 0, 0))
    label_rect = label.get_rect(center=rect.center)
    screen.blit(label, label_rect)


def draw_queue(moving_block=None):
    screen.fill((45, 45, 45))

    title = FONT.render("Queue Visualization - FIFO", True, (255, 255, 255))
    screen.blit(title, (20, 20))

    note = SMALL_FONT.render("Click Enqueue to add at rear. Click Dequeue to remove from front.", True, (230, 230, 230))
    screen.blit(note, (20, 55))

    front_text = SMALL_FONT.render("FRONT", True, (255, 255, 255))
    rear_text = SMALL_FONT.render("REAR", True, (255, 255, 255))
    screen.blit(front_text, (START_X, QUEUE_Y - 45))

    if queue:
        rear_x = START_X + (len(queue) - 1) * (BLOCK_WIDTH + 10)
        screen.blit(rear_text, (rear_x, QUEUE_Y - 45))

    for i, val in enumerate(queue):
        x = START_X + i * (BLOCK_WIDTH + 10)
        rect = pygame.Rect(x, QUEUE_Y, BLOCK_WIDTH, BLOCK_HEIGHT)
        pygame.draw.rect(screen, (100, 180, 255), rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)
        text = FONT.render(str(val), True, (0, 0, 0))
        screen.blit(text, text.get_rect(center=rect.center))

    if moving_block:
        x, y, val = moving_block
        rect = pygame.Rect(x, y, BLOCK_WIDTH, BLOCK_HEIGHT)
        pygame.draw.rect(screen, (255, 180, 100), rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)
        text = FONT.render(str(val), True, (0, 0, 0))
        screen.blit(text, text.get_rect(center=rect.center))

    draw_button(enqueue_button, "Enqueue")
    draw_button(dequeue_button, "Dequeue")

    pygame.display.flip()


def check_quit():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()


def animate_enqueue(value):
    target_x = START_X + len(queue) * (BLOCK_WIDTH + 10)
    y = QUEUE_Y
    x = WIDTH

    while x > target_x:
        check_quit()
        draw_queue((x, y, value))
        x -= 18
        clock.tick(60)


def animate_dequeue(value):
    x = START_X
    y = QUEUE_Y

    while x > -BLOCK_WIDTH:
        check_quit()
        draw_queue((x, y, value))
        x -= 18
        clock.tick(60)


def main():
    global counter

    running = True
    draw_queue()

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if enqueue_button.collidepoint(event.pos):
                    animate_enqueue(counter)
                    queue.append(counter)
                    counter += 1

                elif dequeue_button.collidepoint(event.pos):
                    if queue:
                        value = queue.pop(0)
                        animate_dequeue(value)

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

        draw_queue()
        clock.tick(30)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
