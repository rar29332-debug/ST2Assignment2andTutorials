import unittest
import time
from modules.stack import Stack


class TestStack(unittest.TestCase):
    def test_push_pop(self):
        s = Stack()

        for i in range(1000):
            s.push(i)

        self.assertEqual(s.size(), 1000)

        for i in reversed(range(1000)):
            self.assertEqual(s.pop(), i)

        self.assertTrue(s.is_empty())

    def test_peek_and_exceptions(self):
        s = Stack()

        with self.assertRaises(IndexError):
            s.pop()

        with self.assertRaises(IndexError):
            s.peek()

        s.push(42)
        self.assertEqual(s.peek(), 42)
        self.assertEqual(s.size(), 1)

    def test_benchmark(self):
        s = Stack()
        n = 10 ** 6

        start = time.time()

        for i in range(n):
            s.push(i)

        for _ in range(n):
            s.pop()

        end = time.time()
        elapsed = end - start

        print(f"Benchmark push/pop {n} items: {elapsed:.4f} seconds")
        self.assertTrue(s.is_empty())


if __name__ == "__main__":
    unittest.main()
