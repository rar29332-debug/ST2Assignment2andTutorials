import unittest
import time
from modules.queue_ds import Queue


class TestQueue(unittest.TestCase):
    def test_enqueue_dequeue(self):
        q = Queue()

        for i in range(1000):
            q.enqueue(i)

        self.assertEqual(q.size(), 1000)
        self.assertEqual(q.front(), 0)

        for i in range(1000):
            self.assertEqual(q.dequeue(), i)

        self.assertTrue(q.is_empty())

    def test_exceptions(self):
        q = Queue()

        with self.assertRaises(IndexError):
            q.dequeue()

        with self.assertRaises(IndexError):
            q.front()

    def test_benchmark(self):
        q = Queue()
        n = 10000

        start = time.time()

        for i in range(n):
            q.enqueue(i)

        for _ in range(n):
            q.dequeue()

        end = time.time()
        elapsed = end - start

        print(f"Benchmark enqueue/dequeue {n} items: {elapsed:.4f} seconds")
        self.assertTrue(q.is_empty())


if __name__ == "__main__":
    unittest.main()
