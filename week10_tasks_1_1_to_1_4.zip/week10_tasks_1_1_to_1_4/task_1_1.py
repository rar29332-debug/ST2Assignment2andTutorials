import pygame
import sys
import time

pygame.init()

WIDTH, HEIGHT = 720, 240
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Task 1.1 - Linear Search Visualizer")

FONT = pygame.font.SysFont(None, 34)
SMALL_FONT = pygame.font.SysFont(None, 24)
clock = pygame.time.Clock()

numbers = [5, 3, 9, 1, 7, 4, 10, 2]
cell_width = WIDTH // len(numbers)

input_text = ""
message = "Type a target number & press ENTER."
comparison_count = 0


def draw_grid(highlight_index=None, found_index=None):
    screen.fill((30, 30, 30))

    for i, num in enumerate(numbers):
        color = (210, 210, 210)

        if i == highlight_index:
            color = (255, 120, 120)

        if i == found_index:
            color = (120, 255, 120)

        rect = pygame.Rect(i * cell_width, 70, cell_width - 4, 90)
        pygame.draw.rect(screen, color, rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)

        text = FONT.render(str(num), True, (0, 0, 0))
        text_rect = text.get_rect(center=rect.center)
        screen.blit(text, text_rect)

    title = FONT.render("Linear Search Visualization", True, (255, 255, 255))
    screen.blit(title, (20, 15))

    input_display = SMALL_FONT.render(f"Target input: {input_text}", True, (255, 255, 255))
    screen.blit(input_display, (20, 175))

    info = SMALL_FONT.render(message, True, (255, 255, 255))
    screen.blit(info, (20, 205))

    count_text = SMALL_FONT.render(f"Comparisons: {comparison_count}", True, (255, 255, 255))
    screen.blit(count_text, (WIDTH - 170, 205))

    pygame.display.flip()


def handle_quit_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()


def linear_search(target):
    global comparison_count, message
    comparison_count = 0

    for i, num in enumerate(numbers):
        handle_quit_events()
        comparison_count += 1
        message = f"Comparing target {target} with value {num} at index {i}."
        draw_grid(highlight_index=i)
        time.sleep(0.6)

        if num == target:
            message = f"Found {target} at index {i} after {comparison_count} comparisons."
            draw_grid(found_index=i)
            return i

    message = f"{target} was not found after {comparison_count} comparisons."
    draw_grid()
    return -1


def main():
    global input_text, message

    running = True

    while running:
        draw_grid()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

                elif event.key == pygame.K_RETURN:
                    if input_text.strip() == "":
                        message = "Please type a number before pressing ENTER."
                    else:
                        try:
                            target = int(input_text)
                            linear_search(target)
                            input_text = ""
                            time.sleep(1.5)
                            message = "Type another target number & press ENTER."
                        except ValueError:
                            message = "Invalid input. Please type a valid integer."
                            input_text = ""

                elif event.key == pygame.K_BACKSPACE:
                    input_text = input_text[:-1]

                else:
                    if event.unicode.isdigit() or event.unicode == "-":
                        input_text += event.unicode

        clock.tick(30)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
