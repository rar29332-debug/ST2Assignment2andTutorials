import pygame
import sys

from modules.data_structures_module import DataStructuresModule
from modules.sorting_module import SortingModule
from modules.graphs_module import GraphsModule
from modules.heap_module import HeapModule
from modules.puzzles_module import PuzzlesModule

pygame.init()

WIDTH, HEIGHT = 1000, 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("DSA Explorer and Visualiser App")

FONT = pygame.font.SysFont(None, 38)
SMALL_FONT = pygame.font.SysFont(None, 24)
clock = pygame.time.Clock()

BG = (225, 225, 245)
BUTTON = (155, 155, 210)
BUTTON_HOVER = (185, 185, 235)
BLACK = (0, 0, 0)


def draw_text(text, pos, font=FONT, color=BLACK):
    surface = font.render(text, True, color)
    screen.blit(surface, pos)


def draw_button(rect, text):
    mouse_pos = pygame.mouse.get_pos()
    color = BUTTON_HOVER if rect.collidepoint(mouse_pos) else BUTTON
    pygame.draw.rect(screen, color, rect, border_radius=8)
    pygame.draw.rect(screen, BLACK, rect, 2, border_radius=8)
    label = SMALL_FONT.render(text, True, BLACK)
    screen.blit(label, label.get_rect(center=rect.center))


def main_menu():
    screen.fill(BG)

    draw_text("DSA Explorer and Visualiser App", (260, 60))
    draw_text("Assignment 2 Group Project", (380, 105), SMALL_FONT)

    buttons = {
        "Data Structures": pygame.Rect(380, 170, 240, 55),
        "Sorting": pygame.Rect(380, 245, 240, 55),
        "Graphs": pygame.Rect(380, 320, 240, 55),
        "Heap": pygame.Rect(380, 395, 240, 55),
        "Puzzles": pygame.Rect(380, 470, 240, 55),
        "Exit": pygame.Rect(380, 545, 240, 55),
    }

    for text, rect in buttons.items():
        draw_button(rect, text)

    pygame.display.flip()
    return buttons


def main():
    running = True

    modules = {
        "Data Structures": DataStructuresModule(screen),
        "Sorting": SortingModule(screen),
        "Graphs": GraphsModule(screen),
        "Heap": HeapModule(screen),
        "Puzzles": PuzzlesModule(screen),
    }

    while running:
        buttons = main_menu()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                for name, rect in buttons.items():
                    if rect.collidepoint(event.pos):
                        if name == "Exit":
                            running = False
                        else:
                            modules[name].run()

        clock.tick(30)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
