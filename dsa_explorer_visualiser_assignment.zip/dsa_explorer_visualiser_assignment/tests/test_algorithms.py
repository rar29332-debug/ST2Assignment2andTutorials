import unittest

from modules.algorithms import (
    bubble_sort,
    selection_sort,
    merge_sort,
    bfs_order,
    dfs_order,
    MinHeap,
    count_paths_with_obstacles,
    dijkstra_grid,
)


class TestAlgorithms(unittest.TestCase):
    def test_sorting_algorithms(self):
        data = [5, 3, 8, 1, 2]
        expected = [1, 2, 3, 5, 8]

        self.assertEqual(bubble_sort(data), expected)
        self.assertEqual(selection_sort(data), expected)
        self.assertEqual(merge_sort(data), expected)

    def test_bfs_and_dfs_order(self):
        graph = {
            "A": ["B", "C"],
            "B": ["A", "D", "E"],
            "C": ["A", "F"],
            "D": ["B"],
            "E": ["B", "F"],
            "F": ["C", "E"],
        }

        self.assertEqual(bfs_order(graph, "A"), ["A", "B", "C", "D", "E", "F"])
        self.assertEqual(dfs_order(graph, "A"), ["A", "B", "D", "E", "F", "C"])

    def test_heap_operations(self):
        heap = MinHeap()

        for value in [9, 3, 7, 1, 5]:
            heap.push(value)

        self.assertEqual(heap.pop(), 1)
        self.assertEqual(heap.pop(), 3)
        self.assertEqual(heap.peek(), 5)

    def test_dp_grid_paths(self):
        dp, total = count_paths_with_obstacles(3, 3, {(1, 1)})
        self.assertEqual(total, 2)
        self.assertEqual(dp[2][2], 2)

    def test_dijkstra_grid_pathfinding(self):
        visited, path = dijkstra_grid(3, 3, (0, 0), (2, 2), {(1, 1)})

        self.assertEqual(path[0], (0, 0))
        self.assertEqual(path[-1], (2, 2))
        self.assertTrue(len(path) > 0)


if __name__ == "__main__":
    unittest.main()
