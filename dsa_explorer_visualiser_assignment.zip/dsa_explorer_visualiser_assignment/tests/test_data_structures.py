import unittest

from modules.algorithms import Stack, Queue, LinkedList, BST


class TestDataStructures(unittest.TestCase):
    def test_stack_push_pop_sequence(self):
        stack = Stack()
        stack.push(1)
        stack.push(2)
        stack.push(3)

        self.assertEqual(stack.pop(), 3)
        self.assertEqual(stack.pop(), 2)
        self.assertEqual(stack.size(), 1)
        self.assertEqual(stack.peek(), 1)

    def test_queue_enqueue_dequeue_order(self):
        queue = Queue()

        for value in [1, 2, 3, 4]:
            queue.enqueue(value)

        self.assertEqual(queue.dequeue(), 1)
        self.assertEqual(queue.dequeue(), 2)
        self.assertEqual(queue.dequeue(), 3)
        self.assertEqual(queue.front(), 4)

    def test_linked_list_insert_delete_reverse(self):
        linked = LinkedList()
        linked.append(5)
        linked.append(15)
        linked.insert_at_position(10, 1)

        self.assertEqual(linked.to_list(), [5, 10, 15])

        linked.delete(10)
        self.assertEqual(linked.to_list(), [5, 15])

        linked.reverse()
        self.assertEqual(linked.to_list(), [15, 5])

    def test_bst_traversals_search_delete(self):
        bst = BST()
        for value in [50, 30, 70, 20, 40, 60, 80]:
            bst.insert(value)

        self.assertEqual(bst.inorder(), [20, 30, 40, 50, 60, 70, 80])
        self.assertEqual(bst.preorder(), [50, 30, 20, 40, 70, 60, 80])
        self.assertEqual(bst.postorder(), [20, 40, 30, 60, 80, 70, 50])

        path, found = bst.search_path(60)
        self.assertTrue(found)
        self.assertEqual(path, [50, 70, 60])

        bst.delete(70)
        self.assertEqual(bst.inorder(), [20, 30, 40, 50, 60, 80])


if __name__ == "__main__":
    unittest.main()
