# DSA Explorer and Visualiser App

This is a complete PyGame project for **ST2 Assignment 2 - Group Project**.

## Features

### Main Menu
The app opens with a menu linking to:
- Data Structures
- Sorting
- Graphs
- Heap
- Puzzles

### Data Structures Module
Includes:
- Stack push/pop visualiser
- Queue enqueue/dequeue visualiser
- Linked list insert/delete/reverse editor
- Binary Search Tree insert/search/delete/traversal visualiser

### Sorting Module
Includes:
- Bubble sort visualisation
- Selection sort visualisation
- Merge sort visualisation
- Reset button

### Graphs Module
Includes:
- Interactive graph
- User-selected start node
- BFS visualisation
- DFS visualisation
- Traversal order display

### Heap Module
Includes:
- Min-heap insert
- Extract-min
- Tree and array representation

### Puzzles Module
Includes:
- Pathfinding puzzle using Dijkstra
- Event queue simulator using heap priority queue
- Dynamic programming grid path counting puzzle with obstacles and path reconstruction

## How to Run

Install PyGame:

```bash
pip install pygame
```

Run the app:

```bash
python main.py
```

## How to Run Tests

From the project root:

```bash
python -m unittest discover tests
```

## Folder Structure

```text
dsa_explorer_visualiser_assignment/
  main.py
  modules/
    __init__.py
    ui.py
    algorithms.py
    data_structures_module.py
    sorting_module.py
    graphs_module.py
    heap_module.py
    puzzles_module.py
  tests/
    test_data_structures.py
    test_algorithms.py
  README.md
```

## Controls

General:
- ESC returns to the previous screen.

Data Structures:
- Stack/Queue use buttons.
- Linked List:
  - A = append mode
  - D = delete mode
  - I = insert mode
  - R = reverse
  - ENTER confirms input
- BST:
  - I = insert
  - S = search
  - X = delete
  - 1 = in-order
  - 2 = pre-order
  - 3 = post-order

Graphs:
- Click a node to set the start.
- Press/click BFS or DFS.

Puzzles:
- Pathfinding:
  - Click cells to place obstacles
  - S = set start
  - E = set end
  - O = obstacle mode
  - SPACE = run Dijkstra
- DP Grid:
  - Click cells to place obstacles
  - SPACE = calculate paths
