import pygame
import heapq

from modules.algorithms import dijkstra_grid
from modules.ui import draw_button, draw_top_bar, handle_quit_event, BG, BLACK, BLUE, GREEN, RED, YELLOW, GREY

WIDTH, HEIGHT = 1000, 700


class PuzzlesModule:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.SysFont(None, 30)
        self.small_font = pygame.font.SysFont(None, 22)
        self.clock = pygame.time.Clock()

    def run(self):
        buttons = {
            "Pathfinding Puzzle": pygame.Rect(360, 180, 280, 55),
            "Event Queue Simulator": pygame.Rect(360, 260, 280, 55),
            "DP Grid Puzzle": pygame.Rect(360, 340, 280, 55),
            "Back": pygame.Rect(360, 420, 280, 55),
        }

        running = True
        while running:
            self.screen.fill(BG)
            draw_top_bar(self.screen, "Puzzle Challenges", "Choose a puzzle. ESC returns to main menu.", self.font, self.small_font)

            for text, rect in buttons.items():
                draw_button(self.screen, rect, text, self.font)

            pygame.display.flip()

            for event in pygame.event.get():
                if handle_quit_event(event):
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    for name, rect in buttons.items():
                        if rect.collidepoint(event.pos):
                            if name == "Pathfinding Puzzle":
                                self.pathfinding_puzzle()
                            elif name == "Event Queue Simulator":
                                self.event_queue_puzzle()
                            elif name == "DP Grid Puzzle":
                                self.dp_grid_puzzle()
                            elif name == "Back":
                                running = False

            self.clock.tick(30)

    def pathfinding_puzzle(self):
        rows, cols = 10, 10
        cell = 52
        start = (0, 0)
        end = (9, 9)
        obstacles = {(2, 2), (2, 3), (2, 4), (5, 5), (6, 5), (7, 5)}
        visited = []
        path = []
        mode = "obstacle"
        message = "Click cells to toggle obstacles. Press SPACE for Dijkstra shortest path."

        def draw():
            self.screen.fill(BG)
            draw_top_bar(self.screen, "Pathfinding Puzzle - Dijkstra", message + " | S start | E end | O obstacles | R reset | ESC", self.font, self.small_font)

            for r in range(rows):
                for c in range(cols):
                    rect = pygame.Rect(80 + c * cell, 120 + r * cell, cell, cell)
                    color = GREY
                    if (r, c) in obstacles:
                        color = BLACK
                    if (r, c) in visited:
                        color = YELLOW
                    if (r, c) in path:
                        color = GREEN
                    if (r, c) == start:
                        color = BLUE
                    if (r, c) == end:
                        color = RED

                    pygame.draw.rect(self.screen, color, rect)
                    pygame.draw.rect(self.screen, (80, 80, 80), rect, 1)

            pygame.display.flip()

        def cell_from_pos(pos):
            mx, my = pos
            c = (mx - 80) // cell
            r = (my - 120) // cell
            if 0 <= r < rows and 0 <= c < cols:
                return (r, c)
            return None

        running = True
        while running:
            draw()

            for event in pygame.event.get():
                if handle_quit_event(event):
                    running = False

                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        visited, path = dijkstra_grid(rows, cols, start, end, obstacles)
                        message = f"Shortest path length: {len(path) - 1 if path else 'No path'}"
                    elif event.key == pygame.K_s:
                        mode = "start"
                        message = "Click a cell to set the start."
                    elif event.key == pygame.K_e:
                        mode = "end"
                        message = "Click a cell to set the end."
                    elif event.key == pygame.K_o:
                        mode = "obstacle"
                        message = "Click cells to toggle obstacles."
                    elif event.key == pygame.K_r:
                        obstacles = set()
                        visited = []
                        path = []
                        message = "Grid reset."

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    selected = cell_from_pos(event.pos)
                    if selected:
                        visited = []
                        path = []
                        if mode == "start":
                            if selected != end and selected not in obstacles:
                                start = selected
                        elif mode == "end":
                            if selected != start and selected not in obstacles:
                                end = selected
                        else:
                            if selected not in [start, end]:
                                if selected in obstacles:
                                    obstacles.remove(selected)
                                else:
                                    obstacles.add(selected)

            self.clock.tick(30)

    def event_queue_puzzle(self):
        heap = []
        input_text = ""
        mode = "time"
        temp_time = None
        last_processed = "None"
        message = "Type time, ENTER, then description, ENTER. Or click Process Earliest."

        samples = [(9, "Open lab"), (4, "Start class"), (15, "Team meeting"), (11, "Submit quiz")]
        for item in samples:
            heapq.heappush(heap, item)

        process_btn = pygame.Rect(690, 620, 220, 45)

        def draw():
            self.screen.fill(BG)
            draw_top_bar(self.screen, "Event Queue Simulator", message + " | ESC returns", self.font, self.small_font)
            self.screen.blit(self.small_font.render(f"Mode: {mode} | Input: {input_text}", True, BLACK), (20, 95))
            self.screen.blit(self.small_font.render(f"Last processed: {last_processed}", True, BLACK), (20, 125))

            sorted_events = sorted(heap)
            for i, event in enumerate(sorted_events):
                rect = pygame.Rect(100, 170 + i * 45, 480, 35)
                pygame.draw.rect(self.screen, BLUE, rect, border_radius=5)
                pygame.draw.rect(self.screen, BLACK, rect, 2, border_radius=5)
                label = self.small_font.render(f"Time {event[0]}: {event[1]}", True, BLACK)
                self.screen.blit(label, (rect.x + 10, rect.y + 8))

            draw_button(self.screen, process_btn, "Process Earliest", self.small_font)
            pygame.display.flip()

        running = True
        while running:
            draw()

            for event in pygame.event.get():
                if handle_quit_event(event):
                    running = False

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if process_btn.collidepoint(event.pos):
                        if heap:
                            processed = heapq.heappop(heap)
                            last_processed = f"Time {processed[0]}: {processed[1]}"
                            message = "Processed earliest event."
                        else:
                            message = "No events available."

                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]
                    elif event.key == pygame.K_RETURN:
                        if mode == "time":
                            try:
                                temp_time = int(input_text)
                                input_text = ""
                                mode = "description"
                                message = "Type description and press ENTER."
                            except ValueError:
                                input_text = ""
                                message = "Invalid time."
                        else:
                            if input_text.strip():
                                heapq.heappush(heap, (temp_time, input_text.strip()))
                                input_text = ""
                                mode = "time"
                                message = "Event added."
                    else:
                        if mode == "time":
                            if event.unicode.isdigit() or event.unicode == "-":
                                input_text += event.unicode
                        else:
                            if event.unicode:
                                input_text += event.unicode

            self.clock.tick(30)

    def dp_grid_puzzle(self):
        rows, cols = 6, 6
        cell = 85
        obstacles = {(1, 2), (2, 2), (3, 4), (4, 1)}
        dp = [[None] * cols for _ in range(rows)]
        path = []
        message = "Click cells to toggle obstacles. Press SPACE to count paths and reconstruct one path."

        def draw(highlight=None):
            self.screen.fill(BG)
            draw_top_bar(self.screen, "Dynamic Programming Grid Puzzle", message + " | R reset | ESC returns", self.font, self.small_font)

            for r in range(rows):
                for c in range(cols):
                    rect = pygame.Rect(220 + c * cell, 130 + r * cell, cell, cell)
                    color = GREY
                    if (r, c) in obstacles:
                        color = BLACK
                    if highlight == (r, c):
                        color = RED
                    if (r, c) in path:
                        color = GREEN
                    if (r, c) == (0, 0):
                        color = BLUE
                    if (r, c) == (rows - 1, cols - 1):
                        color = YELLOW

                    pygame.draw.rect(self.screen, color, rect)
                    pygame.draw.rect(self.screen, (80, 80, 80), rect, 2)

                    value = dp[r][c]
                    if value is not None and (r, c) not in obstacles:
                        label = self.font.render(str(value), True, BLACK)
                        self.screen.blit(label, label.get_rect(center=rect.center))

            pygame.display.flip()

        def compute():
            nonlocal dp, path, message
            parent = [[None] * cols for _ in range(rows)]
            dp = [[0] * cols for _ in range(rows)]
            path = []

            for r in range(rows):
                for c in range(cols):
                    if (r, c) in obstacles:
                        dp[r][c] = 0
                    elif (r, c) == (0, 0):
                        dp[r][c] = 1
                    else:
                        up = dp[r - 1][c] if r > 0 else 0
                        left = dp[r][c - 1] if c > 0 else 0
                        dp[r][c] = up + left

                        if r > 0 and dp[r - 1][c] > 0:
                            parent[r][c] = (r - 1, c)
                        elif c > 0 and dp[r][c - 1] > 0:
                            parent[r][c] = (r, c - 1)

                    draw((r, c))
                    pygame.time.wait(250)

            total = dp[rows - 1][cols - 1]
            message = f"Total unique paths: {total}"

            if total > 0:
                current = (rows - 1, cols - 1)
                while current is not None:
                    path.append(current)
                    cr, cc = current
                    current = parent[cr][cc]
                path.reverse()

        def cell_from_pos(pos):
            mx, my = pos
            c = (mx - 220) // cell
            r = (my - 130) // cell
            if 0 <= r < rows and 0 <= c < cols:
                return (r, c)
            return None

        running = True
        while running:
            draw()

            for event in pygame.event.get():
                if handle_quit_event(event):
                    running = False

                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        compute()
                    elif event.key == pygame.K_r:
                        obstacles = {(1, 2), (2, 2), (3, 4), (4, 1)}
                        dp = [[None] * cols for _ in range(rows)]
                        path = []
                        message = "Reset."

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    selected = cell_from_pos(event.pos)
                    if selected and selected not in [(0, 0), (rows - 1, cols - 1)]:
                        if selected in obstacles:
                            obstacles.remove(selected)
                        else:
                            obstacles.add(selected)
                        dp = [[None] * cols for _ in range(rows)]
                        path = []

            self.clock.tick(30)
