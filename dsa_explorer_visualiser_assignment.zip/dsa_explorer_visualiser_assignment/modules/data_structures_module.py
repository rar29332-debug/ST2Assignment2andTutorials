import pygame
import sys

from modules.algorithms import Stack, Queue, LinkedList, BST, BSTNode
from modules.ui import draw_button, draw_top_bar, handle_quit_event, BG, BLACK, BLUE, GREEN, RED, YELLOW, GREY, DARK

WIDTH, HEIGHT = 1000, 700


class DataStructuresModule:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.SysFont(None, 30)
        self.small_font = pygame.font.SysFont(None, 22)
        self.clock = pygame.time.Clock()

    def run(self):
        running = True
        selected = None

        buttons = {
            "Stack": pygame.Rect(380, 150, 240, 50),
            "Queue": pygame.Rect(380, 220, 240, 50),
            "Linked List": pygame.Rect(380, 290, 240, 50),
            "BST": pygame.Rect(380, 360, 240, 50),
            "Back": pygame.Rect(380, 430, 240, 50),
        }

        while running:
            self.screen.fill(BG)
            draw_top_bar(self.screen, "Data Structures Module", "Choose a visualiser. ESC returns to main menu.", self.font, self.small_font)

            for text, rect in buttons.items():
                draw_button(self.screen, rect, text, self.font)

            pygame.display.flip()

            for event in pygame.event.get():
                if handle_quit_event(event):
                    running = False

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    for name, rect in buttons.items():
                        if rect.collidepoint(event.pos):
                            if name == "Stack":
                                self.stack_screen()
                            elif name == "Queue":
                                self.queue_screen()
                            elif name == "Linked List":
                                self.linked_list_screen()
                            elif name == "BST":
                                self.bst_screen()
                            elif name == "Back":
                                running = False

            self.clock.tick(30)

    def stack_screen(self):
        stack = Stack()
        counter = 1
        push_btn = pygame.Rect(250, 610, 160, 45)
        pop_btn = pygame.Rect(590, 610, 160, 45)
        running = True

        while running:
            self.screen.fill(DARK)
            draw_top_bar(self.screen, "Stack Visualiser", "LIFO: push adds to top, pop removes from top. Click buttons or press ESC.", self.font, self.small_font)

            data = stack.to_list()
            block_w, block_h = 220, 42
            x = (WIDTH - block_w) // 2
            base_y = 560

            for i, value in enumerate(data):
                rect = pygame.Rect(x, base_y - i * (block_h + 6), block_w, block_h)
                pygame.draw.rect(self.screen, BLUE, rect)
                pygame.draw.rect(self.screen, BLACK, rect, 2)
                label = self.font.render(str(value), True, BLACK)
                self.screen.blit(label, label.get_rect(center=rect.center))

            draw_button(self.screen, push_btn, "Push", self.font)
            draw_button(self.screen, pop_btn, "Pop", self.font)
            pygame.display.flip()

            for event in pygame.event.get():
                if handle_quit_event(event):
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if push_btn.collidepoint(event.pos):
                        stack.push(counter)
                        counter += 1
                    elif pop_btn.collidepoint(event.pos) and not stack.is_empty():
                        stack.pop()

            self.clock.tick(30)

    def queue_screen(self):
        queue = Queue()
        counter = 1
        enqueue_btn = pygame.Rect(250, 610, 160, 45)
        dequeue_btn = pygame.Rect(590, 610, 160, 45)
        running = True

        while running:
            self.screen.fill(DARK)
            draw_top_bar(self.screen, "Queue Visualiser", "FIFO: enqueue adds to rear, dequeue removes from front. Click buttons or press ESC.", self.font, self.small_font)

            start_x, y = 120, 320
            block_w, block_h = 75, 55

            for i, value in enumerate(queue.to_list()):
                rect = pygame.Rect(start_x + i * (block_w + 10), y, block_w, block_h)
                pygame.draw.rect(self.screen, BLUE, rect)
                pygame.draw.rect(self.screen, BLACK, rect, 2)
                label = self.font.render(str(value), True, BLACK)
                self.screen.blit(label, label.get_rect(center=rect.center))

            self.screen.blit(self.small_font.render("FRONT", True, (255, 255, 255)), (start_x, y - 35))
            if queue.size() > 0:
                self.screen.blit(self.small_font.render("REAR", True, (255, 255, 255)), (start_x + (queue.size() - 1) * 85, y + 65))

            draw_button(self.screen, enqueue_btn, "Enqueue", self.font)
            draw_button(self.screen, dequeue_btn, "Dequeue", self.font)
            pygame.display.flip()

            for event in pygame.event.get():
                if handle_quit_event(event):
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if enqueue_btn.collidepoint(event.pos):
                        queue.enqueue(counter)
                        counter += 1
                    elif dequeue_btn.collidepoint(event.pos) and not queue.is_empty():
                        queue.dequeue()

            self.clock.tick(30)

    def linked_list_screen(self):
        linked = LinkedList()
        for v in [5, 10, 15]:
            linked.append(v)

        input_text = ""
        mode = "append"
        message = "A append | D delete | I insert value,pos | R reverse"
        running = True

        while running:
            self.screen.fill(BG)
            draw_top_bar(self.screen, "Linked List Editor", message + " | ENTER confirms | ESC returns", self.font, self.small_font)
            self.screen.blit(self.small_font.render(f"Mode: {mode} | Input: {input_text}", True, BLACK), (20, 95))

            values = linked.to_list()
            x0, y = 90, 330
            gap = 135
            radius = 27

            for i, value in enumerate(values):
                x = x0 + i * gap
                pygame.draw.circle(self.screen, BLUE, (x, y), radius)
                pygame.draw.circle(self.screen, BLACK, (x, y), radius, 2)
                label = self.font.render(str(value), True, BLACK)
                self.screen.blit(label, label.get_rect(center=(x, y)))

                if i < len(values) - 1:
                    pygame.draw.line(self.screen, BLACK, (x + radius, y), (x + gap - radius, y), 3)
                    pygame.draw.polygon(self.screen, BLACK, [(x + gap - radius, y), (x + gap - radius - 10, y - 6), (x + gap - radius - 10, y + 6)])

            pygame.display.flip()

            for event in pygame.event.get():
                if handle_quit_event(event):
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_a:
                        mode, input_text, message = "append", "", "Append: type value and press ENTER"
                    elif event.key == pygame.K_d:
                        mode, input_text, message = "delete", "", "Delete: type value and press ENTER"
                    elif event.key == pygame.K_i:
                        mode, input_text, message = "insert", "", "Insert: type value,position and press ENTER"
                    elif event.key == pygame.K_r:
                        linked.reverse()
                        message = "Linked list reversed."
                    elif event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]
                    elif event.key == pygame.K_RETURN:
                        try:
                            if mode == "append":
                                linked.append(int(input_text))
                            elif mode == "delete":
                                linked.delete(int(input_text))
                            elif mode == "insert":
                                v, p = input_text.split(",")
                                linked.insert_at_position(int(v.strip()), int(p.strip()))
                            input_text = ""
                        except Exception:
                            message = "Invalid input."
                            input_text = ""
                    elif event.unicode in "0123456789-,":
                        input_text += event.unicode

            self.clock.tick(30)

    def bst_screen(self):
        bst = BST()
        for v in [50, 30, 70, 20, 40, 60, 80]:
            bst.insert(v)

        input_text = ""
        mode = "insert"
        highlighted_values = set()
        traversal_text = ""
        message = "I insert | S search | X delete | 1 inorder | 2 preorder | 3 postorder"
        running = True

        def collect_positions(node, x, y, offset, positions):
            if node:
                positions[node.value] = (x, y)
                collect_positions(node.left, x - offset, y + 85, max(offset // 2, 35), positions)
                collect_positions(node.right, x + offset, y + 85, max(offset // 2, 35), positions)

        def draw_edges_and_nodes(node, positions):
            if node:
                x, y = positions[node.value]
                if node.left:
                    pygame.draw.line(self.screen, BLACK, (x, y), positions[node.left.value], 3)
                    draw_edges_and_nodes(node.left, positions)
                if node.right:
                    pygame.draw.line(self.screen, BLACK, (x, y), positions[node.right.value], 3)
                    draw_edges_and_nodes(node.right, positions)

                color = RED if node.value in highlighted_values else BLUE
                pygame.draw.circle(self.screen, color, (x, y), 25)
                pygame.draw.circle(self.screen, BLACK, (x, y), 25, 2)
                label = self.font.render(str(node.value), True, BLACK)
                self.screen.blit(label, label.get_rect(center=(x, y)))

        while running:
            self.screen.fill(BG)
            draw_top_bar(self.screen, "Binary Search Tree Visualiser", message + " | ENTER confirms | ESC returns", self.font, self.small_font)
            self.screen.blit(self.small_font.render(f"Mode: {mode} | Input: {input_text}", True, BLACK), (20, 95))
            self.screen.blit(self.small_font.render(traversal_text, True, BLACK), (20, 640))

            positions = {}
            collect_positions(bst.root, WIDTH // 2, 150, 230, positions)
            draw_edges_and_nodes(bst.root, positions)

            pygame.display.flip()

            for event in pygame.event.get():
                if handle_quit_event(event):
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_i:
                        mode, input_text = "insert", ""
                    elif event.key == pygame.K_s:
                        mode, input_text = "search", ""
                    elif event.key == pygame.K_x:
                        mode, input_text = "delete", ""
                    elif event.key == pygame.K_1:
                        order = bst.inorder()
                        traversal_text = "In-order: " + " -> ".join(map(str, order))
                        highlighted_values = set(order)
                    elif event.key == pygame.K_2:
                        order = bst.preorder()
                        traversal_text = "Pre-order: " + " -> ".join(map(str, order))
                        highlighted_values = set(order)
                    elif event.key == pygame.K_3:
                        order = bst.postorder()
                        traversal_text = "Post-order: " + " -> ".join(map(str, order))
                        highlighted_values = set(order)
                    elif event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]
                    elif event.key == pygame.K_RETURN:
                        try:
                            value = int(input_text)
                            if mode == "insert":
                                bst.insert(value)
                                highlighted_values = {value}
                            elif mode == "search":
                                path, found = bst.search_path(value)
                                highlighted_values = set(path)
                                traversal_text = f"Search path for {value}: " + " -> ".join(map(str, path))
                            elif mode == "delete":
                                bst.delete(value)
                                highlighted_values = set()
                            input_text = ""
                        except Exception:
                            input_text = ""
                    elif event.unicode.isdigit() or event.unicode == "-":
                        input_text += event.unicode

            self.clock.tick(30)
