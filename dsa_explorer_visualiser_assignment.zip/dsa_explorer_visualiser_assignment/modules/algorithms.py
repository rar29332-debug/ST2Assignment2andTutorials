import heapq
from collections import deque


class Stack:
    def __init__(self):
        self._data = []

    def push(self, value):
        self._data.append(value)

    def pop(self):
        if self.is_empty():
            raise IndexError("pop from empty stack")
        return self._data.pop()

    def peek(self):
        if self.is_empty():
            raise IndexError("peek from empty stack")
        return self._data[-1]

    def is_empty(self):
        return len(self._data) == 0

    def size(self):
        return len(self._data)

    def to_list(self):
        return list(self._data)


class Queue:
    def __init__(self):
        self._data = []

    def enqueue(self, value):
        self._data.append(value)

    def dequeue(self):
        if self.is_empty():
            raise IndexError("dequeue from empty queue")
        return self._data.pop(0)

    def front(self):
        if self.is_empty():
            raise IndexError("front from empty queue")
        return self._data[0]

    def is_empty(self):
        return len(self._data) == 0

    def size(self):
        return len(self._data)

    def to_list(self):
        return list(self._data)


class LinkedListNode:
    def __init__(self, value):
        self.value = value
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, value):
        new_node = LinkedListNode(value)
        if self.head is None:
            self.head = new_node
            return

        current = self.head
        while current.next:
            current = current.next
        current.next = new_node

    def insert_at_position(self, value, position):
        new_node = LinkedListNode(value)

        if position <= 0 or self.head is None:
            new_node.next = self.head
            self.head = new_node
            return

        current = self.head
        index = 0
        while current.next and index < position - 1:
            current = current.next
            index += 1

        new_node.next = current.next
        current.next = new_node

    def delete(self, value):
        current = self.head
        previous = None

        while current:
            if current.value == value:
                if previous:
                    previous.next = current.next
                else:
                    self.head = current.next
                return True

            previous = current
            current = current.next

        return False

    def reverse(self):
        previous = None
        current = self.head

        while current:
            nxt = current.next
            current.next = previous
            previous = current
            current = nxt

        self.head = previous

    def to_list(self):
        result = []
        current = self.head
        while current:
            result.append(current.value)
            current = current.next
        return result


class BSTNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, value):
        def _insert(node, value):
            if node is None:
                return BSTNode(value)
            if value < node.value:
                node.left = _insert(node.left, value)
            elif value > node.value:
                node.right = _insert(node.right, value)
            return node

        self.root = _insert(self.root, value)

    def inorder(self):
        result = []

        def _inorder(node):
            if node:
                _inorder(node.left)
                result.append(node.value)
                _inorder(node.right)

        _inorder(self.root)
        return result

    def preorder(self):
        result = []

        def _preorder(node):
            if node:
                result.append(node.value)
                _preorder(node.left)
                _preorder(node.right)

        _preorder(self.root)
        return result

    def postorder(self):
        result = []

        def _postorder(node):
            if node:
                _postorder(node.left)
                _postorder(node.right)
                result.append(node.value)

        _postorder(self.root)
        return result

    def search_path(self, value):
        path = []
        current = self.root

        while current:
            path.append(current.value)
            if current.value == value:
                return path, True
            if value < current.value:
                current = current.left
            else:
                current = current.right

        return path, False

    def delete(self, value):
        def find_min(node):
            while node.left:
                node = node.left
            return node

        def _delete(node, value):
            if node is None:
                return None

            if value < node.value:
                node.left = _delete(node.left, value)
            elif value > node.value:
                node.right = _delete(node.right, value)
            else:
                if node.left is None:
                    return node.right
                if node.right is None:
                    return node.left

                successor = find_min(node.right)
                node.value = successor.value
                node.right = _delete(node.right, successor.value)

            return node

        self.root = _delete(self.root, value)


def bubble_sort(values):
    arr = list(values)
    n = len(arr)
    for i in range(n):
        for j in range(n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
    return arr


def selection_sort(values):
    arr = list(values)
    for i in range(len(arr)):
        min_index = i
        for j in range(i + 1, len(arr)):
            if arr[j] < arr[min_index]:
                min_index = j
        arr[i], arr[min_index] = arr[min_index], arr[i]
    return arr


def merge_sort(values):
    arr = list(values)
    if len(arr) <= 1:
        return arr

    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])

    result = []
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])
    return result


def bfs_order(graph, start):
    visited = set()
    queue = deque([start])
    order = []

    while queue:
        node = queue.popleft()
        if node in visited:
            continue

        visited.add(node)
        order.append(node)

        for neighbour in graph[node]:
            if neighbour not in visited and neighbour not in queue:
                queue.append(neighbour)

    return order


def dfs_order(graph, start):
    visited = set()
    stack = [start]
    order = []

    while stack:
        node = stack.pop()
        if node in visited:
            continue

        visited.add(node)
        order.append(node)

        for neighbour in reversed(graph[node]):
            if neighbour not in visited:
                stack.append(neighbour)

    return order


class MinHeap:
    def __init__(self):
        self._data = []

    def push(self, item):
        heapq.heappush(self._data, item)

    def pop(self):
        if not self._data:
            raise IndexError("pop from empty heap")
        return heapq.heappop(self._data)

    def peek(self):
        if not self._data:
            raise IndexError("peek from empty heap")
        return self._data[0]

    def to_list(self):
        return list(self._data)

    def size(self):
        return len(self._data)


def count_paths_with_obstacles(rows, cols, obstacles):
    dp = [[0 for _ in range(cols)] for _ in range(rows)]

    for r in range(rows):
        for c in range(cols):
            if (r, c) in obstacles:
                dp[r][c] = 0
            elif (r, c) == (0, 0):
                dp[r][c] = 1
            else:
                up = dp[r - 1][c] if r > 0 else 0
                left = dp[r][c - 1] if c > 0 else 0
                dp[r][c] = up + left

    return dp, dp[rows - 1][cols - 1]


def dijkstra_grid(rows, cols, start, end, obstacles):
    pq = [(0, start)]
    distances = {start: 0}
    parent = {start: None}
    visited_order = []

    while pq:
        distance, current = heapq.heappop(pq)

        if current in visited_order:
            continue

        visited_order.append(current)

        if current == end:
            break

        r, c = current
        neighbours = [(r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)]

        for nr, nc in neighbours:
            if 0 <= nr < rows and 0 <= nc < cols and (nr, nc) not in obstacles:
                new_distance = distance + 1
                neighbour = (nr, nc)

                if neighbour not in distances or new_distance < distances[neighbour]:
                    distances[neighbour] = new_distance
                    parent[neighbour] = current
                    heapq.heappush(pq, (new_distance, neighbour))

    path = []
    if end in parent:
        current = end
        while current is not None:
            path.append(current)
            current = parent[current]
        path.reverse()

    return visited_order, path
