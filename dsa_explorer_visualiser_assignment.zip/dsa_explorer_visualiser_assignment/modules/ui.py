import pygame

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BG = (240, 240, 245)
BUTTON = (165, 165, 220)
BUTTON_HOVER = (190, 190, 240)
BLUE = (100, 180, 255)
GREEN = (120, 230, 120)
RED = (255, 120, 120)
YELLOW = (255, 220, 120)
GREY = (210, 210, 210)
DARK = (45, 45, 45)


def draw_button(screen, rect, text, font, base_color=BUTTON):
    mouse = pygame.mouse.get_pos()
    color = BUTTON_HOVER if rect.collidepoint(mouse) else base_color
    pygame.draw.rect(screen, color, rect, border_radius=8)
    pygame.draw.rect(screen, BLACK, rect, 2, border_radius=8)
    label = font.render(text, True, BLACK)
    screen.blit(label, label.get_rect(center=rect.center))


def draw_top_bar(screen, title, instruction, font, small_font):
    pygame.draw.rect(screen, (230, 230, 250), (0, 0, screen.get_width(), 86))
    title_text = font.render(title, True, BLACK)
    screen.blit(title_text, (20, 15))
    instruction_text = small_font.render(instruction, True, BLACK)
    screen.blit(instruction_text, (20, 52))


def handle_quit_event(event):
    return event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE)
