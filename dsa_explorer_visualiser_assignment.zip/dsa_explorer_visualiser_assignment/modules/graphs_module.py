import pygame
from collections import deque

from modules.ui import draw_button, draw_top_bar, handle_quit_event, BG, BLACK, BLUE, GREEN, RED, YELLOW, GREY

WIDTH, HEIGHT = 1000, 700


class GraphsModule:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.SysFont(None, 30)
        self.small_font = pygame.font.SysFont(None, 22)
        self.clock = pygame.time.Clock()
        self.nodes_pos = {
            "A": (130, 170),
            "B": (310, 110),
            "C": (310, 260),
            "D": (520, 160),
            "E": (710, 230),
            "F": (520, 390),
        }
        self.graph = {
            "A": ["B", "C"],
            "B": ["A", "D", "E"],
            "C": ["A", "F"],
            "D": ["B"],
            "E": ["B", "F"],
            "F": ["C", "E"],
        }
        self.selected_start = None
        self.message = "Click a start node, then choose BFS or DFS."
        self.order = []

    def draw_graph(self, visited=None, frontier=None, current=None):
        visited = visited or set()
        frontier = frontier or set()

        self.screen.fill(BG)
        draw_top_bar(self.screen, "Graph Traversal Visualiser", self.message + " | ESC returns", self.font, self.small_font)

        buttons = {
            "BFS": pygame.Rect(760, 30, 90, 38),
            "DFS": pygame.Rect(870, 30, 90, 38),
        }

        for text, rect in buttons.items():
            draw_button(self.screen, rect, text, self.small_font)

        self.screen.blit(self.small_font.render(f"Selected start node: {self.selected_start}", True, BLACK), (20, 95))
        self.screen.blit(self.small_font.render("Traversal order: " + (" -> ".join(self.order) if self.order else "None"), True, BLACK), (20, 640))

        drawn = set()
        for node, neighbours in self.graph.items():
            x1, y1 = self.nodes_pos[node]
            for neighbour in neighbours:
                edge = tuple(sorted((node, neighbour)))
                if edge not in drawn:
                    x2, y2 = self.nodes_pos[neighbour]
                    pygame.draw.line(self.screen, BLACK, (x1, y1), (x2, y2), 3)
                    drawn.add(edge)

        for node, (x, y) in self.nodes_pos.items():
            color = GREY
            if node == self.selected_start:
                color = (180, 180, 255)
            if node in visited:
                color = GREEN
            if node in frontier:
                color = YELLOW
            if node == current:
                color = RED

            pygame.draw.circle(self.screen, color, (x, y), 30)
            pygame.draw.circle(self.screen, BLACK, (x, y), 30, 2)
            label = self.font.render(node, True, BLACK)
            self.screen.blit(label, label.get_rect(center=(x, y)))

        pygame.display.flip()
        return buttons

    def clicked_node(self, pos):
        mx, my = pos
        for node, (x, y) in self.nodes_pos.items():
            if ((mx - x) ** 2 + (my - y) ** 2) ** 0.5 <= 30:
                return node
        return None

    def bfs(self):
        if not self.selected_start:
            self.message = "Please click a start node first."
            return

        visited = set()
        queue = deque([self.selected_start])
        self.order = []

        while queue:
            current = queue.popleft()
            if current in visited:
                continue

            visited.add(current)
            self.order.append(current)
            self.message = f"BFS visiting {current}"
            self.draw_graph(visited, set(queue), current)
            pygame.time.wait(600)

            for neighbour in self.graph[current]:
                if neighbour not in visited and neighbour not in queue:
                    queue.append(neighbour)

        self.message = "BFS completed."

    def dfs(self):
        if not self.selected_start:
            self.message = "Please click a start node first."
            return

        visited = set()
        stack = [self.selected_start]
        self.order = []

        while stack:
            current = stack.pop()
            if current in visited:
                continue

            visited.add(current)
            self.order.append(current)
            self.message = f"DFS visiting {current}"
            self.draw_graph(visited, set(stack), current)
            pygame.time.wait(600)

            for neighbour in reversed(self.graph[current]):
                if neighbour not in visited:
                    stack.append(neighbour)

        self.message = "DFS completed."

    def run(self):
        running = True

        while running:
            buttons = self.draw_graph()

            for event in pygame.event.get():
                if handle_quit_event(event):
                    running = False

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    node = self.clicked_node(event.pos)

                    if node:
                        self.selected_start = node
                        self.order = []
                        self.message = f"Selected {node}. Choose BFS or DFS."
                    elif buttons["BFS"].collidepoint(event.pos):
                        self.bfs()
                    elif buttons["DFS"].collidepoint(event.pos):
                        self.dfs()

                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_b:
                        self.bfs()
                    elif event.key == pygame.K_d:
                        self.dfs()

            self.clock.tick(30)
