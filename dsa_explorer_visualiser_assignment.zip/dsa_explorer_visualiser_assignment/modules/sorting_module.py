import pygame
import random
import sys

from modules.ui import draw_button, draw_top_bar, handle_quit_event, BG, BLACK, BLUE, GREEN, RED, YELLOW

WIDTH, HEIGHT = 1000, 700


class SortingModule:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.SysFont(None, 30)
        self.small_font = pygame.font.SysFont(None, 22)
        self.clock = pygame.time.Clock()
        self.array = []
        self.reset_array()
        self.message = "Choose Bubble Sort, Selection Sort, Merge Sort, or Reset."

    def reset_array(self):
        self.array = [random.randint(30, 440) for _ in range(42)]

    def draw_array(self, compare=None, swap=None, sorted_indices=None, active_range=None):
        compare = compare or []
        swap = swap or []
        sorted_indices = sorted_indices or []

        self.screen.fill((35, 35, 40))
        draw_top_bar(self.screen, "Sorting Algorithm Visualiser", self.message + " | ESC returns", self.font, self.small_font)

        bar_width = WIDTH // len(self.array)

        for i, value in enumerate(self.array):
            color = BLUE
            if active_range and active_range[0] <= i <= active_range[1]:
                color = (170, 170, 255)
            if i in compare:
                color = RED
            if i in swap:
                color = GREEN
            if i in sorted_indices:
                color = YELLOW

            rect = pygame.Rect(i * bar_width, 600 - value, bar_width - 2, value)
            pygame.draw.rect(self.screen, color, rect)

        buttons = {
            "Bubble Sort": pygame.Rect(70, 620, 170, 45),
            "Selection Sort": pygame.Rect(280, 620, 170, 45),
            "Merge Sort": pygame.Rect(490, 620, 170, 45),
            "Reset": pygame.Rect(700, 620, 170, 45),
        }

        for text, rect in buttons.items():
            draw_button(self.screen, rect, text, self.small_font)

        pygame.display.flip()
        return buttons

    def check_events(self):
        for event in pygame.event.get():
            if handle_quit_event(event):
                return False
        return True

    def bubble_sort(self):
        self.message = "Running Bubble Sort: comparing and swapping adjacent bars."
        n = len(self.array)

        for i in range(n):
            for j in range(n - i - 1):
                if not self.check_events():
                    return
                self.draw_array(compare=[j, j + 1], sorted_indices=list(range(n - i, n)))
                pygame.time.wait(30)

                if self.array[j] > self.array[j + 1]:
                    self.array[j], self.array[j + 1] = self.array[j + 1], self.array[j]
                    self.draw_array(swap=[j, j + 1], sorted_indices=list(range(n - i, n)))
                    pygame.time.wait(30)

        self.message = "Bubble Sort completed."
        self.draw_array(sorted_indices=list(range(n)))

    def selection_sort(self):
        self.message = "Running Selection Sort: selecting the minimum item."
        n = len(self.array)

        for i in range(n):
            min_index = i

            for j in range(i + 1, n):
                if not self.check_events():
                    return
                self.draw_array(compare=[min_index, j], sorted_indices=list(range(i)))
                pygame.time.wait(35)

                if self.array[j] < self.array[min_index]:
                    min_index = j

            self.array[i], self.array[min_index] = self.array[min_index], self.array[i]
            self.draw_array(swap=[i, min_index], sorted_indices=list(range(i + 1)))
            pygame.time.wait(60)

        self.message = "Selection Sort completed."
        self.draw_array(sorted_indices=list(range(n)))

    def merge_sort(self):
        self.message = "Running Merge Sort: splitting and merging sub-arrays."

        def sort(left, right):
            if left >= right:
                return

            mid = (left + right) // 2
            self.draw_array(active_range=(left, right))
            pygame.time.wait(100)

            sort(left, mid)
            sort(mid + 1, right)

            left_part = self.array[left:mid + 1]
            right_part = self.array[mid + 1:right + 1]

            i = j = 0
            k = left

            while i < len(left_part) and j < len(right_part):
                if not self.check_events():
                    return

                if left_part[i] <= right_part[j]:
                    self.array[k] = left_part[i]
                    i += 1
                else:
                    self.array[k] = right_part[j]
                    j += 1

                self.draw_array(swap=[k], active_range=(left, right))
                pygame.time.wait(45)
                k += 1

            while i < len(left_part):
                self.array[k] = left_part[i]
                self.draw_array(swap=[k], active_range=(left, right))
                pygame.time.wait(45)
                i += 1
                k += 1

            while j < len(right_part):
                self.array[k] = right_part[j]
                self.draw_array(swap=[k], active_range=(left, right))
                pygame.time.wait(45)
                j += 1
                k += 1

        sort(0, len(self.array) - 1)
        self.message = "Merge Sort completed."
        self.draw_array(sorted_indices=list(range(len(self.array))))

    def run(self):
        running = True

        while running:
            buttons = self.draw_array()

            for event in pygame.event.get():
                if handle_quit_event(event):
                    running = False

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if buttons["Bubble Sort"].collidepoint(event.pos):
                        self.bubble_sort()
                    elif buttons["Selection Sort"].collidepoint(event.pos):
                        self.selection_sort()
                    elif buttons["Merge Sort"].collidepoint(event.pos):
                        self.merge_sort()
                    elif buttons["Reset"].collidepoint(event.pos):
                        self.reset_array()
                        self.message = "Array reset."

            self.clock.tick(30)
