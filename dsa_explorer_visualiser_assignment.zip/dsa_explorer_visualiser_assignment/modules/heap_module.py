import pygame
import random
import math

from modules.ui import draw_button, draw_top_bar, handle_quit_event, BG, BLACK, BLUE, RED

WIDTH, HEIGHT = 1000, 700


class HeapModule:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.SysFont(None, 30)
        self.small_font = pygame.font.SysFont(None, 22)
        self.clock = pygame.time.Clock()
        self.heap = []
        self.counter = 1
        self.message = "Click Insert to add random value. Click Extract Min to remove root."

    def draw_heap(self, highlight=None):
        highlight = highlight or []

        self.screen.fill(BG)
        draw_top_bar(self.screen, "Min-Heap Visualiser", self.message + " | ESC returns", self.font, self.small_font)

        buttons = {
            "Insert": pygame.Rect(240, 620, 160, 45),
            "Extract Min": pygame.Rect(430, 620, 180, 45),
            "Reset": pygame.Rect(640, 620, 160, 45),
        }

        for text, rect in buttons.items():
            draw_button(self.screen, rect, text, self.small_font)

        if not self.heap:
            empty = self.font.render("Heap is empty", True, BLACK)
            self.screen.blit(empty, empty.get_rect(center=(WIDTH // 2, HEIGHT // 2)))
        else:
            positions = []

            for i in range(len(self.heap)):
                level = int(math.floor(math.log2(i + 1)))
                index_in_level = i - (2 ** level - 1)
                gap = 760 // (2 ** level + 1)
                x = 120 + gap * (index_in_level + 1)
                y = 160 + level * 85
                positions.append((x, y))

            for i in range(len(self.heap)):
                left = 2 * i + 1
                right = 2 * i + 2
                if left < len(self.heap):
                    pygame.draw.line(self.screen, BLACK, positions[i], positions[left], 3)
                if right < len(self.heap):
                    pygame.draw.line(self.screen, BLACK, positions[i], positions[right], 3)

            for i, value in enumerate(self.heap):
                color = RED if i in highlight else BLUE
                pygame.draw.circle(self.screen, color, positions[i], 28)
                pygame.draw.circle(self.screen, BLACK, positions[i], 28, 2)
                label = self.font.render(str(value), True, BLACK)
                self.screen.blit(label, label.get_rect(center=positions[i]))

            array_text = self.small_font.render("Array form: " + str(self.heap), True, BLACK)
            self.screen.blit(array_text, (20, 585))

        pygame.display.flip()
        return buttons

    def heapify_up(self, index):
        while index > 0:
            parent = (index - 1) // 2
            if self.heap[parent] > self.heap[index]:
                self.heap[parent], self.heap[index] = self.heap[index], self.heap[parent]
                self.draw_heap([parent, index])
                pygame.time.wait(450)
                index = parent
            else:
                break

    def heapify_down(self, index):
        n = len(self.heap)
        while True:
            left = 2 * index + 1
            right = 2 * index + 2
            smallest = index

            if left < n and self.heap[left] < self.heap[smallest]:
                smallest = left
            if right < n and self.heap[right] < self.heap[smallest]:
                smallest = right

            if smallest != index:
                self.heap[index], self.heap[smallest] = self.heap[smallest], self.heap[index]
                self.draw_heap([index, smallest])
                pygame.time.wait(450)
                index = smallest
            else:
                break

    def insert(self, value):
        self.heap.append(value)
        self.draw_heap([len(self.heap) - 1])
        pygame.time.wait(350)
        self.heapify_up(len(self.heap) - 1)

    def extract_min(self):
        if not self.heap:
            self.message = "Heap is empty."
            return

        root = self.heap[0]
        if len(self.heap) == 1:
            self.heap.pop()
            self.message = f"Extracted {root}."
            return

        self.heap[0] = self.heap[-1]
        self.heap.pop()
        self.draw_heap([0])
        pygame.time.wait(350)
        self.heapify_down(0)
        self.message = f"Extracted minimum value {root}."

    def run(self):
        running = True

        while running:
            buttons = self.draw_heap()

            for event in pygame.event.get():
                if handle_quit_event(event):
                    running = False

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if buttons["Insert"].collidepoint(event.pos):
                        value = random.randint(1, 99)
                        self.message = f"Inserted {value}."
                        self.insert(value)

                    elif buttons["Extract Min"].collidepoint(event.pos):
                        self.extract_min()

                    elif buttons["Reset"].collidepoint(event.pos):
                        self.heap.clear()
                        self.message = "Heap reset."

            self.clock.tick(30)
