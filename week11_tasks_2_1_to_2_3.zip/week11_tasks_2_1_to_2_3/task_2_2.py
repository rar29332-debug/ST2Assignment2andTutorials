import pygame
import sys

pygame.init()

WIDTH, HEIGHT = 1000, 650
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Task 2.2 - BST Visualizer")

FONT = pygame.font.SysFont(None, 28)
SMALL_FONT = pygame.font.SysFont(None, 22)
clock = pygame.time.Clock()

NODE_RADIUS = 22
input_text = ""
mode = "insert"
message = "I: insert | S: search | D: delete | 1: inorder | 2: preorder | 3: postorder | ENTER: confirm | ESC: quit"


class BSTNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, value):
        def _insert(node, value):
            if node is None:
                return BSTNode(value)

            if value < node.value:
                node.left = _insert(node.left, value)
            elif value > node.value:
                node.right = _insert(node.right, value)

            return node

        self.root = _insert(self.root, value)

    def inorder(self):
        result = []

        def _inorder(node):
            if node:
                _inorder(node.left)
                result.append(node)
                _inorder(node.right)

        _inorder(self.root)
        return result

    def preorder(self):
        result = []

        def _preorder(node):
            if node:
                result.append(node)
                _preorder(node.left)
                _preorder(node.right)

        _preorder(self.root)
        return result

    def postorder(self):
        result = []

        def _postorder(node):
            if node:
                _postorder(node.left)
                _postorder(node.right)
                result.append(node)

        _postorder(self.root)
        return result

    def search_path(self, value):
        path = []
        current = self.root

        while current:
            path.append(current)

            if current.value == value:
                return path, True
            elif value < current.value:
                current = current.left
            else:
                current = current.right

        return path, False

    def delete(self, value):
        def find_min(node):
            while node.left:
                node = node.left
            return node

        def _delete(node, value):
            if node is None:
                return None

            if value < node.value:
                node.left = _delete(node.left, value)

            elif value > node.value:
                node.right = _delete(node.right, value)

            else:
                if node.left is None and node.right is None:
                    return None

                if node.left is None:
                    return node.right

                if node.right is None:
                    return node.left

                successor = find_min(node.right)
                node.value = successor.value
                node.right = _delete(node.right, successor.value)

            return node

        self.root = _delete(self.root, value)


def draw_node(x, y, value, highlight=False):
    color = (255, 120, 120) if highlight else (100, 200, 250)
    pygame.draw.circle(screen, color, (x, y), NODE_RADIUS)
    pygame.draw.circle(screen, (0, 0, 0), (x, y), NODE_RADIUS, 2)

    text = FONT.render(str(value), True, (0, 0, 0))
    screen.blit(text, text.get_rect(center=(x, y)))


def draw_edge(start_pos, end_pos):
    pygame.draw.line(screen, (0, 0, 0), start_pos, end_pos, 3)


def collect_positions(node, x, y, x_offset, positions):
    if node:
        positions[node] = (x, y)
        collect_positions(node.left, x - x_offset, y + 85, max(x_offset // 2, 35), positions)
        collect_positions(node.right, x + x_offset, y + 85, max(x_offset // 2, 35), positions)


def draw_tree(node, positions, highlighted_nodes=None):
    if highlighted_nodes is None:
        highlighted_nodes = set()

    if node:
        x, y = positions[node]

        if node.left:
            draw_edge((x, y), positions[node.left])
            draw_tree(node.left, positions, highlighted_nodes)

        if node.right:
            draw_edge((x, y), positions[node.right])
            draw_tree(node.right, positions, highlighted_nodes)

        draw_node(x, y, node.value, node in highlighted_nodes)


def draw_screen(bst, highlighted_nodes=None, traversal_order=None):
    screen.fill((240, 240, 240))

    title = FONT.render("Binary Search Tree Visualizer", True, (0, 0, 0))
    screen.blit(title, (20, 15))

    info = SMALL_FONT.render(message, True, (0, 0, 0))
    screen.blit(info, (20, 45))

    input_display = SMALL_FONT.render(f"Mode: {mode.upper()} | Input: {input_text}", True, (0, 0, 0))
    screen.blit(input_display, (20, 70))

    if traversal_order:
        order_text = "Traversal order: " + " -> ".join(str(node.value) for node in traversal_order)
        rendered = SMALL_FONT.render(order_text, True, (0, 0, 0))
        screen.blit(rendered, (20, HEIGHT - 35))

    positions = {}
    collect_positions(bst.root, WIDTH // 2, 130, 230, positions)
    draw_tree(bst.root, positions, highlighted_nodes)

    pygame.display.flip()


def animate_nodes(bst, nodes, final_message):
    highlighted = set()

    for node in nodes:
        highlighted.add(node)
        draw_screen(bst, highlighted_nodes=highlighted, traversal_order=nodes)
        pygame.time.wait(650)

    global message
    message = final_message


def main():
    global input_text, mode, message

    bst = BST()
    for value in [50, 30, 70, 20, 40, 60, 80]:
        bst.insert(value)

    running = True

    while running:
        draw_screen(bst)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

                elif event.key == pygame.K_i:
                    mode = "insert"
                    input_text = ""
                    message = "Insert mode: type a number and press ENTER."

                elif event.key == pygame.K_s:
                    mode = "search"
                    input_text = ""
                    message = "Search mode: type a number and press ENTER."

                elif event.key == pygame.K_d:
                    mode = "delete"
                    input_text = ""
                    message = "Delete mode: type a number and press ENTER."

                elif event.key == pygame.K_1:
                    nodes = bst.inorder()
                    animate_nodes(bst, nodes, "In-order traversal completed.")

                elif event.key == pygame.K_2:
                    nodes = bst.preorder()
                    animate_nodes(bst, nodes, "Pre-order traversal completed.")

                elif event.key == pygame.K_3:
                    nodes = bst.postorder()
                    animate_nodes(bst, nodes, "Post-order traversal completed.")

                elif event.key == pygame.K_BACKSPACE:
                    input_text = input_text[:-1]

                elif event.key == pygame.K_RETURN:
                    try:
                        value = int(input_text)

                        if mode == "insert":
                            bst.insert(value)
                            message = f"Inserted {value}."

                        elif mode == "search":
                            path, found = bst.search_path(value)
                            result = "found" if found else "not found"
                            animate_nodes(bst, path, f"{value} {result}. Search path highlighted.")

                        elif mode == "delete":
                            bst.delete(value)
                            message = f"Deleted {value} if it existed."

                        input_text = ""

                    except ValueError:
                        message = "Invalid input. Please type an integer."
                        input_text = ""

                else:
                    if event.unicode.isdigit() or event.unicode == "-":
                        input_text += event.unicode

        clock.tick(30)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
