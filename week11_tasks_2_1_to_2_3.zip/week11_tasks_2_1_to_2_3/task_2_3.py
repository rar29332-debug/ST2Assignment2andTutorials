import pygame
import random
import sys

pygame.init()

WIDTH, HEIGHT = 850, 500
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Task 2.3 - Sorting Algorithm Visualizer")

FONT = pygame.font.SysFont(None, 28)
SMALL_FONT = pygame.font.SysFont(None, 22)
clock = pygame.time.Clock()

ARRAY_SIZE = 35
array = [random.randint(30, 360) for _ in range(ARRAY_SIZE)]
bar_width = WIDTH // ARRAY_SIZE

bubble_button = pygame.Rect(30, 430, 150, 45)
selection_button = pygame.Rect(210, 430, 150, 45)
merge_button = pygame.Rect(390, 430, 150, 45)
reset_button = pygame.Rect(570, 430, 150, 45)

message = "Choose a sorting algorithm."


def draw_button(rect, text):
    pygame.draw.rect(screen, (160, 160, 220), rect)
    pygame.draw.rect(screen, (0, 0, 0), rect, 2)
    label = SMALL_FONT.render(text, True, (0, 0, 0))
    screen.blit(label, label.get_rect(center=rect.center))


def draw_array(values, compare=None, swap=None, sorted_indices=None, active_range=None):
    if compare is None:
        compare = []
    if swap is None:
        swap = []
    if sorted_indices is None:
        sorted_indices = []

    screen.fill((30, 30, 30))

    title = FONT.render("Sorting Algorithm Visualizer", True, (255, 255, 255))
    screen.blit(title, (20, 15))

    status = SMALL_FONT.render(message, True, (255, 255, 255))
    screen.blit(status, (20, 45))

    for i, val in enumerate(values):
        color = (100, 200, 250)

        if active_range and active_range[0] <= i <= active_range[1]:
            color = (170, 170, 255)

        if i in compare:
            color = (255, 120, 120)

        if i in swap:
            color = (120, 255, 120)

        if i in sorted_indices:
            color = (200, 255, 150)

        x = i * bar_width
        y = 400 - val
        pygame.draw.rect(screen, color, (x, y, bar_width - 2, val))

    draw_button(bubble_button, "Bubble Sort")
    draw_button(selection_button, "Selection Sort")
    draw_button(merge_button, "Merge Sort")
    draw_button(reset_button, "Reset Array")

    pygame.display.flip()


def check_quit_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()


def bubble_sort_visualize(values):
    global message
    n = len(values)
    message = "Running Bubble Sort..."

    for i in range(n):
        for j in range(0, n - i - 1):
            check_quit_events()
            draw_array(values, compare=[j, j + 1], sorted_indices=list(range(n - i, n)))
            pygame.time.wait(40)

            if values[j] > values[j + 1]:
                values[j], values[j + 1] = values[j + 1], values[j]
                draw_array(values, swap=[j, j + 1], sorted_indices=list(range(n - i, n)))
                pygame.time.wait(40)

    message = "Bubble Sort completed."
    draw_array(values, sorted_indices=list(range(n)))


def selection_sort_visualize(values):
    global message
    n = len(values)
    message = "Running Selection Sort..."

    for i in range(n):
        min_index = i

        for j in range(i + 1, n):
            check_quit_events()
            draw_array(values, compare=[min_index, j], sorted_indices=list(range(i)))
            pygame.time.wait(45)

            if values[j] < values[min_index]:
                min_index = j

        values[i], values[min_index] = values[min_index], values[i]
        draw_array(values, swap=[i, min_index], sorted_indices=list(range(i + 1)))
        pygame.time.wait(80)

    message = "Selection Sort completed."
    draw_array(values, sorted_indices=list(range(n)))


def merge_sort_visualize(values):
    global message
    message = "Running Merge Sort..."

    def merge_sort(left, right):
        if left >= right:
            return

        mid = (left + right) // 2

        draw_array(values, active_range=(left, right))
        pygame.time.wait(160)

        merge_sort(left, mid)
        merge_sort(mid + 1, right)

        left_part = values[left:mid + 1]
        right_part = values[mid + 1:right + 1]

        i = j = 0
        k = left

        while i < len(left_part) and j < len(right_part):
            check_quit_events()
            draw_array(values, compare=[k], active_range=(left, right))
            pygame.time.wait(70)

            if left_part[i] <= right_part[j]:
                values[k] = left_part[i]
                i += 1
            else:
                values[k] = right_part[j]
                j += 1

            draw_array(values, swap=[k], active_range=(left, right))
            pygame.time.wait(70)
            k += 1

        while i < len(left_part):
            check_quit_events()
            values[k] = left_part[i]
            draw_array(values, swap=[k], active_range=(left, right))
            pygame.time.wait(70)
            i += 1
            k += 1

        while j < len(right_part):
            check_quit_events()
            values[k] = right_part[j]
            draw_array(values, swap=[k], active_range=(left, right))
            pygame.time.wait(70)
            j += 1
            k += 1

    merge_sort(0, len(values) - 1)
    message = "Merge Sort completed."
    draw_array(values, sorted_indices=list(range(len(values))))


def reset_array():
    global array, message
    array = [random.randint(30, 360) for _ in range(ARRAY_SIZE)]
    message = "Array reset. Choose a sorting algorithm."


def main():
    global message

    running = True

    while running:
        draw_array(array)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if bubble_button.collidepoint(event.pos):
                    bubble_sort_visualize(array)

                elif selection_button.collidepoint(event.pos):
                    selection_sort_visualize(array)

                elif merge_button.collidepoint(event.pos):
                    merge_sort_visualize(array)

                elif reset_button.collidepoint(event.pos):
                    reset_array()

        clock.tick(30)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
