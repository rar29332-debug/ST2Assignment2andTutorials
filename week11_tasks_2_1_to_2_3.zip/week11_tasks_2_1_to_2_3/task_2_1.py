import pygame
import sys

pygame.init()

WIDTH, HEIGHT = 1000, 320
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Task 2.1 - Linked List Visualizer")

FONT = pygame.font.SysFont(None, 28)
SMALL_FONT = pygame.font.SysFont(None, 22)
clock = pygame.time.Clock()

NODE_RADIUS = 25
NODE_GAP = 130

input_text = ""
mode = "append"
message = "A: append | D: delete | I: insert at position | R: reverse | ENTER: confirm | ESC: quit"


class Node:
    def __init__(self, value):
        self.value = value
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, value):
        new_node = Node(value)

        if self.head is None:
            self.head = new_node
            return

        current = self.head
        while current.next:
            current = current.next
        current.next = new_node

    def delete(self, value):
        current = self.head
        previous = None

        while current:
            if current.value == value:
                if previous:
                    previous.next = current.next
                else:
                    self.head = current.next
                return True

            previous = current
            current = current.next

        return False

    def insert_at_position(self, value, position):
        new_node = Node(value)

        if position <= 0 or self.head is None:
            new_node.next = self.head
            self.head = new_node
            return

        current = self.head
        index = 0

        while current.next and index < position - 1:
            current = current.next
            index += 1

        new_node.next = current.next
        current.next = new_node

    def reverse(self):
        previous = None
        current = self.head

        while current:
            next_node = current.next
            current.next = previous
            previous = current
            current = next_node

        self.head = previous

    def to_list(self):
        values = []
        current = self.head

        while current:
            values.append(current.value)
            current = current.next

        return values


def draw_arrow(start_pos, end_pos):
    pygame.draw.line(screen, (0, 0, 0), start_pos, end_pos, 3)

    end_x, end_y = end_pos
    arrow_head = [
        (end_x - 12, end_y - 8),
        (end_x, end_y),
        (end_x - 12, end_y + 8)
    ]
    pygame.draw.polygon(screen, (0, 0, 0), arrow_head)


def draw_node(x, y, value, highlight=False):
    color = (255, 120, 120) if highlight else (100, 200, 250)
    pygame.draw.circle(screen, color, (x, y), NODE_RADIUS)
    pygame.draw.circle(screen, (0, 0, 0), (x, y), NODE_RADIUS, 2)

    text = FONT.render(str(value), True, (0, 0, 0))
    screen.blit(text, text.get_rect(center=(x, y)))


def draw_linked_list(linked_list, highlight_index=None):
    screen.fill((240, 240, 240))

    title = FONT.render("Linked List Visualizer", True, (0, 0, 0))
    screen.blit(title, (20, 15))

    info = SMALL_FONT.render(message, True, (0, 0, 0))
    screen.blit(info, (20, 45))

    input_display = SMALL_FONT.render(f"Mode: {mode.upper()} | Input: {input_text}", True, (0, 0, 0))
    screen.blit(input_display, (20, 70))

    help_text = SMALL_FONT.render("For insert, type value,position  e.g. 25,2", True, (0, 0, 0))
    screen.blit(help_text, (20, 95))

    values = linked_list.to_list()
    y = 190
    start_x = 80

    for i, value in enumerate(values):
        x = start_x + i * NODE_GAP
        draw_node(x, y, value, highlight=(i == highlight_index))

        if i < len(values) - 1:
            start = (x + NODE_RADIUS, y)
            end = (x + NODE_GAP - NODE_RADIUS, y)
            draw_arrow(start, end)

    pygame.display.flip()


def animate_reverse(linked_list):
    values = linked_list.to_list()

    for i in range(len(values)):
        draw_linked_list(linked_list, highlight_index=i)
        pygame.time.wait(300)

    linked_list.reverse()

    reversed_values = linked_list.to_list()
    for i in range(len(reversed_values)):
        draw_linked_list(linked_list, highlight_index=i)
        pygame.time.wait(300)


def main():
    global input_text, mode, message

    linked_list = LinkedList()

    for value in [5, 10, 15]:
        linked_list.append(value)

    running = True

    while running:
        draw_linked_list(linked_list)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

                elif event.key == pygame.K_a:
                    mode = "append"
                    input_text = ""
                    message = "Append mode: type a value and press ENTER."

                elif event.key == pygame.K_d:
                    mode = "delete"
                    input_text = ""
                    message = "Delete mode: type a value and press ENTER."

                elif event.key == pygame.K_i:
                    mode = "insert"
                    input_text = ""
                    message = "Insert mode: type value,position and press ENTER. Example: 25,2"

                elif event.key == pygame.K_r:
                    message = "Reversing linked list..."
                    animate_reverse(linked_list)
                    message = "Linked list reversed."

                elif event.key == pygame.K_BACKSPACE:
                    input_text = input_text[:-1]

                elif event.key == pygame.K_RETURN:
                    try:
                        if mode == "append":
                            linked_list.append(int(input_text))
                            message = f"Appended {input_text}."

                        elif mode == "delete":
                            deleted = linked_list.delete(int(input_text))
                            message = f"Deleted {input_text}." if deleted else f"{input_text} not found."

                        elif mode == "insert":
                            value_text, position_text = input_text.split(",")
                            value = int(value_text.strip())
                            position = int(position_text.strip())
                            linked_list.insert_at_position(value, position)
                            message = f"Inserted {value} at position {position}."

                        input_text = ""

                    except Exception:
                        message = "Invalid input. Please check the format."
                        input_text = ""

                else:
                    allowed = "0123456789-,"
                    if event.unicode in allowed:
                        input_text += event.unicode

        clock.tick(30)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
