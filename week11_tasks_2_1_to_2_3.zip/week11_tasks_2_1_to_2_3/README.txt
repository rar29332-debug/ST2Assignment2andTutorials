Week 11 Tasks 2.1 to 2.3 - PyGame DSA Playground

Install pygame:
pip install pygame

Run each task:
python task_2_1.py
python task_2_2.py
python task_2_3.py

Task 2.1 Controls:
A = append mode
D = delete mode
I = insert at position mode
R = reverse linked list
ENTER = confirm input
ESC = quit

Task 2.2 Controls:
I = insert mode
S = search mode
D = delete mode
1 = in-order traversal
2 = pre-order traversal
3 = post-order traversal
ENTER = confirm input
ESC = quit

Task 2.3:
Use the on-screen buttons to run Bubble Sort, Selection Sort, Merge Sort, or reset the array.
